
from odoo import models, fields, _
from odoo.exceptions import UserError
import base64
import openpyxl
from io import BytesIO

class ImportPAWizard(models.TransientModel):
    _name = 'import.pa.wizard'
    _description = 'Import Purchase Agreement Wizard'

    file = fields.Binary('Excel File', required=True)
    filename = fields.Char('Filename')
    purchase_requisition_id = fields.Many2one('purchase.requisition', string='Purchase Agreement')

    def import_file(self):
        if not self.file:
            raise UserError(_('Please upload a file.'))

        file_content = base64.b64decode(self.file)
        workbook = openpyxl.load_workbook(filename=BytesIO(file_content), data_only=True)
        sheet = workbook.active

        products = []
        first = True
        for row in sheet.iter_rows(min_row=2, values_only=True):
            product_name, qty, uom_name, price = row

            product = self.env['product.product'].search([('name', '=', product_name)], limit=1)
            if not product:
                uom = self.env['uom.uom'].search([('name', '=', uom_name)], limit=1)
                if not uom:
                    raise UserError(_('UOM %s not found') % uom_name)
                product = self.env['product.product'].create({
                    'name': product_name,
                    'uom_id': uom.id,
                })

            products.append((product, qty, price))

        for product, qty, price in products:
            self.purchase_requisition_id.line_ids.create({
                'requisition_id': self.purchase_requisition_id.id,
                'product_id': product.id,
                'product_qty': qty,
                'price_unit': price,
                'product_uom_id': product.uom_id.id,
            })

