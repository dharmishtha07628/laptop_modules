from odoo import models, fields, api

class RateRevisionWizard(models.TransientModel):
    _name = 'rate.revision.wizard'
    _description = 'Wizard to Revise Line Rate'

    line_id = fields.Many2one('purchase.requisition.line', required=True)
    new_rate = fields.Float(string='New Rate (Incl. GST)', required=True)
    reason = fields.Text(string='Reason for Revision', required=True)

    def apply_revision(self):
        self.ensure_one()
        self.line_id.revise_rate(self.new_rate, self.reason)
