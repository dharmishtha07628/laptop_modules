{
    'name': 'Custom Purchase Agreement Import',
    'version': '18.0.1.0.0',
    'depends': ['purchase_requisition', 'product'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/import_pa_wizard_views.xml',
        'wizard/rate_revision_wizard_view.xml',
        'views/purchase_agreement_views.xml',
        'views/purchase_qc_view.xml',
        'views/purchase_requisition_line_revision_view.xml',
    ],
    'installable': True,
    'application': False,
}
