
# Custom Purchase Agreement Import

## How to Use
1. Install the module.
2. Go to Purchase Agreements.
3. Open an agreement.
4. Click 'Import Products' in the header.
5. Upload an XLSX file with columns: Product Name | Quantity | UOM | Price.

## Notes
- Products and UOMs are created if not found.
- New lines are added to the existing agreement.
