from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class PurchaseQualityCheck(models.Model):
    _name = 'purchase.quality.check'
    _description = 'Purchase Quality Check'

    purchase_order_id = fields.Many2one('purchase.order', string='Purchase Order', required=True, ondelete='cascade')
    line_ids = fields.One2many('purchase.quality.check.line', 'quality_check_id', string='Product Checks')
    name = fields.Char(string='Reference', default='/')

    def create(self, vals):
        if vals.get('name', '/') == '/':
            vals['name'] = self.env['ir.sequence'].next_by_code('purchase.quality.check') or '/'
        return super().create(vals)


class PurchaseQualityCheckLine(models.Model):
    _name = 'purchase.quality.check.line'
    _description = 'Quality Check Line'

    quality_check_id = fields.Many2one('purchase.quality.check', string='Quality Check', required=True,
                                       ondelete='cascade')
    product_id = fields.Many2one('product.product', string='Product', required=True)
    product_qty = fields.Float(string='Quantity')
    product_uom_id = fields.Many2one(
        'uom.uom',
        string='Unit of Measure',
        required=True,
        domain="[('category_id', '=', category_id)]"
    )
    category_id = fields.Many2one(
        'uom.category',
        string='UoM Category',
        related='product_id.uom_id.category_id',
        store=True,
        readonly=True
    )
    remarks = fields.Text(string='Remarks')
    status = fields.Selection([
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string='Status', default='pending')


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    quality_check_id = fields.One2many('purchase.quality.check', 'purchase_order_id', string='Quality Check')

    def action_open_quality_check(self):
        self.ensure_one()
        if not self.quality_check_id:
            qc = self.env['purchase.quality.check'].create({
                'purchase_order_id': self.id,
                'line_ids': [
                    (0, 0, {
                        'product_id': line.product_id.id,
                        'product_qty': line.product_qty,
                    }) for line in self.order_line
                ]
            })
            self.quality_check_id = qc

        return {
            'type': 'ir.actions.act_window',
            'name': 'Quality Check',
            'res_model': 'purchase.quality.check',
            'view_mode': 'form',
            'res_id': self.quality_check_id.id,
            'target': 'current'
        }

    def button_confirm(self):
        for order in self:
            if order.requisition_id:
                if order.quality_check_id:
                    rejected = order.quality_check_id.line_ids.filtered(lambda l: l.status == 'rejected')
                    pending = order.quality_check_id.line_ids.filtered(lambda l: l.status == 'pending')

                    if rejected:
                        raise ValidationError(_('Quality check failed: Some products are rejected. Cannot confirm.'))
                    if pending:
                        raise ValidationError(
                            _('Quality check pending: Please approve or reject all products before confirming.'))
        return super().button_confirm()
