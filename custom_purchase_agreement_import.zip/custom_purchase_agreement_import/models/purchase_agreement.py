from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class PurchaseRequisition(models.Model):
    _inherit = 'purchase.requisition'

    total_amount = fields.Monetary(string='Total Amount', compute='_compute_total_amount', store=True, currency_field='currency_id')
    total_agreement_amount = fields.Monetary(string='Total Agreement Amount', currency_field='currency_id')
    cgm_unit_id = fields.Many2one('cgm.unit', string='CGM Unit')
    nature_of_work = fields.Char(string='Nature of Work')
    name_of_work = fields.Char(string='Name of Work')
    date_of_completion = fields.Date(string='Date of Completion')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True, default=lambda self: self.env.company.currency_id)

    @api.depends('line_ids.product_qty', 'line_ids.price_unit')
    def _compute_total_amount(self):
        for rec in self:
            total = 0.0
            for line in rec.line_ids:
                total += line.product_qty * line.price_unit
            rec.total_amount = total

    def action_validate_amounts(self):
        for rec in self:
            if rec.total_agreement_amount and rec.total_amount > rec.total_agreement_amount:
                raise ValidationError(_('The Total Amount (%s) exceeds the Total Agreement Amount (%s).') % (rec.total_amount, rec.total_agreement_amount))

    def action_confirm(self):
        self.action_validate_amounts()
        return super().action_confirm()

    def create_subcontracts(self):
        for requisition in self:
            if not requisition.vendor_id:
                raise ValidationError(_('Please select a vendor before creating subcontracts.'))
            selected_lines = requisition.line_ids.filtered('is_selected')
            if not selected_lines:
                raise ValidationError(_('Please select at least one line to create a subcontract.'))

            po_vals = {
                'partner_id': requisition.vendor_id.id if hasattr(requisition, 'vendor_id') else False,
                'requisition_id': requisition.id,
                'order_line': []
            }

            for line in selected_lines:
                po_line = (0, 0, {
                    'product_id': line.product_id.id,
                    'product_qty': line.product_qty,
                    'product_uom': line.product_uom_id.id,
                    'price_unit': line.price_unit,
                    'name': line.product_id.display_name,
                    'date_planned': fields.Date.today(),
                })
                po_vals['order_line'].append(po_line)

            purchase_order = self.env['purchase.order'].create(po_vals)

            # Uncheck the selected flag
            selected_lines.write({'is_selected': False})

            # Open created PO
            return {
                'type': 'ir.actions.act_window',
                'name': 'Purchase Order',
                'view_mode': 'form',
                'res_model': 'purchase.order',
                'res_id': purchase_order.id,
            }


class CGMUnit(models.Model):
    _name = 'cgm.unit'
    _description = 'CGM Unit'

    name = fields.Char('Name', required=True)


class PurchaseRequisitionLine(models.Model):
    _inherit = 'purchase.requisition.line'

    is_selected = fields.Boolean('Select')
    requests = fields.Integer(string='Requests', compute='_compute_requests', store=True)
    line_revision_ids = fields.One2many('purchase.requisition.line.revision', 'line_id', string='Line Revisions')

    @api.depends('product_id', 'requisition_id.purchase_ids.order_line')
    def _compute_requests(self):
        for line in self:
            po_lines = self.env['purchase.order.line'].search([
                ('order_id.requisition_id', '=', line.requisition_id.id),
                ('product_id', '=', line.product_id.id)
            ])
            line.requests = len(po_lines)

    def revise_rate(self, new_rate, reason):
        for line in self:
            self.env['purchase.requisition.line.revision'].create({
                'line_id': line.id,
                'previous_rate': line.price_unit,
                'new_rate': new_rate,
                'reason': reason,
            })
            line.price_unit = new_rate

    def action_view_revisions(self):
        self.ensure_one()
        return {
            'name': 'Rate Revisions',
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.requisition.line.revision',
            'view_mode': 'list,form',
            'domain': [('line_id', '=', self.id)],
            'context': {'default_line_id': self.id},
        }