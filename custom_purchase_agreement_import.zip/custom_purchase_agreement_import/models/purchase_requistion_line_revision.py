from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import datetime

class PurchaseRequisitionLineRevision(models.Model):
    _name = 'purchase.requisition.line.revision'
    _description = 'Line-Level Price Revision'
    _order = 'revision_date desc'

    line_id = fields.Many2one('purchase.requisition.line', string='Requisition Line', ondelete='cascade')
    previous_rate = fields.Float(string='Previous Rate (Incl. GST)')
    new_rate = fields.Float(string='New Rate (Incl. GST)')
    gst_percent = fields.Float(string='GST %')
    revision_date = fields.Datetime(string='Revision Date', default=fields.Datetime.now)
    reason = fields.Text(string='Reason for Change')