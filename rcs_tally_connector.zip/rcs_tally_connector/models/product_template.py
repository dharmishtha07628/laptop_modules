import uuid
import requests
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError
import xml.etree.ElementTree as ET
from datetime import date
from bs4 import BeautifulSoup


class ProductTemplate(models.Model):
    _inherit = "product.template"

    tally_operation = fields.Selection([
        ('fetch', 'Fetch from Tally'),
        ('export', 'Export to Tally'),
        ('none', 'No Action')
    ], default='none')
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance")
    guid = fields.Char(string="Tally connected GUID", help="Unique identifier from Tally for this product")
    tally_response = fields.Text(string="Tally Response")
    tally_exported = fields.Boolean()

    def build_stock_request_xml(self):
        return """
        <ENVELOPE>
    <HEADER>
        <VERSION>1</VERSION>
        <TALLYREQUEST>Export</TALLYREQUEST>
        <TYPE>Collection</TYPE>
        <ID>StockItemDetails</ID>
    </HEADER>
    <BODY>
        <DESC>
            <TDL>
                <TDLMESSAGE>
                    <COLLECTION NAME="StockItemDetails" ISMODIFY="No">
                        <TYPE>StockItem</TYPE>

                        <!-- Basic Info -->
                        <NATIVEMETHOD>NAME</NATIVEMETHOD>
                        <NATIVEMETHOD>PARENT</NATIVEMETHOD>
                        <NATIVEMETHOD>GUID</NATIVEMETHOD>
                        <NATIVEMETHOD>Alias</NATIVEMETHOD>
                        <NATIVEMETHOD>IsActive</NATIVEMETHOD>

                        <!-- Classification -->
                        <NATIVEMETHOD>StockGroupName</NATIVEMETHOD>
                        <NATIVEMETHOD>Category</NATIVEMETHOD>
                        <NATIVEMETHOD>HSNCode</NATIVEMETHOD>

                        <!-- UOM -->
                        <NATIVEMETHOD>BaseUnits</NATIVEMETHOD>
                        <NATIVEMETHOD>AdditionalUnits</NATIVEMETHOD>

                        <!-- GST Info -->
                        <NATIVEMETHOD>GSTApplicable</NATIVEMETHOD>
                        <NATIVEMETHOD>Taxability</NATIVEMETHOD>
                        <NATIVEMETHOD>GSTDetails</NATIVEMETHOD>

                        <!-- Rates -->
                        <NATIVEMETHOD>RateOfDuty</NATIVEMETHOD>
                        <NATIVEMETHOD>StandardCost</NATIVEMETHOD>
                        <NATIVEMETHOD>StandardPrice</NATIVEMETHOD>

                        <!-- Stock & Valuation -->
                        <NATIVEMETHOD>OpeningBalance</NATIVEMETHOD>
                        <NATIVEMETHOD>OpeningValue</NATIVEMETHOD>
                        <NATIVEMETHOD>ClosingBalance</NATIVEMETHOD>
                        <NATIVEMETHOD>ClosingValue</NATIVEMETHOD>
                        <NATIVEMETHOD>ValuationMethod</NATIVEMETHOD>
                    </COLLECTION>
                </TDLMESSAGE>
            </TDL>
        </DESC>
    </BODY>
</ENVELOPE>

            """

    def import_tally_stock_items(self, xml_string, instance):
        soup = BeautifulSoup(xml_string, "xml")
        collection = soup.find("COLLECTION")
        stock_items = collection.find_all('STOCKITEM')
        for stock_item in stock_items:
            # Get product name
            name_node = stock_item.get('NAME')
            product_name = name_node if name_node is not None else 'Unnamed Product'

            # Get base unit (UoM)
            uom_text = stock_item.BASEUNITS.text if stock_item.BASEUNITS else None
            hsn_code_list = stock_item.find('HSNDETAILS.LIST')
            hsn_code = stock_item.find('HSNMASTERNAME') if hsn_code_list else None
            guid = stock_item.GUID.text if stock_item.GUID else ''
            existing_product = self.search([('guid', '=', guid)], limit=1)
            if existing_product:
                continue

            def safe_float(value, default=0.0):
                try:
                    # Keep only numeric characters, decimal point, and minus sign
                    clean_value = ''.join(ch for ch in value if ch.isdigit() or ch in ['.', '-'])
                    return float(clean_value) if clean_value else default
                except Exception:
                    return default

            sale_price = safe_float(stock_item.STANDARDPRICE.text, 0.0) if stock_item.STANDARDPRICE else 0.0
            purchase_price = safe_float(stock_item.STANDARDCOST.text, 0.0) if stock_item.STANDARDCOST else 0.0

            # Create or find UoM
            uom = self.env['uom.uom'].search([('name', '=', uom_text)], limit=1)
            if not uom:
                # Reuse existing category or create new one for this UoM
                category = self.env['uom.category'].search([('name', '=', uom_text)], limit=1)
                if not category:
                    category = self.env['uom.category'].create({'name': uom_text})

                # Decide UoM type safely
                reference_exists = self.env['uom.uom'].search([
                    ('category_id', '=', category.id),
                    ('uom_type', '=', 'reference')
                ], limit=1)

                uom_type = 'smaller' if reference_exists else 'reference'
                factor = 1.0 if uom_type == 'reference' else 1.0  # adjust if needed

                uom = self.env['uom.uom'].create({
                    'name': uom_text,
                    'uom_type': uom_type,
                    'category_id': category.id,
                    'factor': factor,
                    'rounding': 1.0
                })

            # Create or find Product
            product = self.env['product.product'].search([('name', '=', product_name)], limit=1)
            if not product:
                product = self.env['product.product'].create({
                    'name': product_name,
                    'uom_id': uom.id,
                    'uom_po_id': uom.id,
                    'type': 'consu',
                    'is_storable': True,
                    'list_price': float(sale_price),
                    'standard_price': float(purchase_price),
                    'default_code': product_name[:64].replace(" ", "_").upper(),
                    'tally_instance_id': instance.id,
                    'tally_operation': 'fetch',
                    'guid': guid,
                })
                self.env.cr.commit()


            # Update HSN
            if hsn_code:
                product.product_tmpl_id.l10n_in_hsn_code = hsn_code

            # Handle batch allocations
            batch_list = stock_item.find_all('BATCHALLOCATIONS.LIST')
            for batch in batch_list:
                location_name = batch.GODOWNNAME.text if batch.GODOWNNAME else 'Default Location'
                qty_text = batch.OPENINGBALANCE.text.strip().split(' ')[0] if batch.OPENINGBALANCE else '0'
                qty = float(qty_text)
                value = float(batch.OPENINGVALUE.text.strip()) if batch.OPENINGVALUE else 0.0

                # Create or find location
                location = self.env['stock.location'].search([
                    ('name', '=', location_name),
                    ('usage', '=', 'internal')
                ], limit=1)
                if not location:
                    location = self.env['stock.location'].create({
                        'name': location_name,
                        'usage': 'internal'
                    })

                # Create or update stock quant
                quant = self.env['stock.quant'].search([
                    ('product_id', '=', product.id),
                    ('location_id', '=', location.id),
                ], limit=1)

                if quant:
                    quant.quantity = qty
                    quant.value = value
                else:
                    self.env['stock.quant'].create({
                        'product_id': product.id,
                        'location_id': location.id,
                        'quantity': qty,
                        'value': value,
                    })

            category = stock_item.CATEGORY.text if stock_item.CATEGORY else None
            if category:
                odoo_category = self.env['product.category'].search([('name', '=', category)], limit=1)
                if odoo_category:
                    set_category = odoo_category.id
                    product.categ_id = set_category

    def action_export_tally(self):
        """
        Send Sale Order to Tally on button click
        """
        self.ensure_one()
        for product in self:
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {product.name}",
                'message': 'Stock Item Export to Tally initiated.',
                'company_id': product.tally_instance_id.company_id.id,
                'res_model': 'purchase.order',
                'res_id': product.id,
            })
            if not product.tally_instance_id or not product.tally_instance_id.url:
                raise UserError("No Tally instance URL configured.")

            payload = product.generate_tally_product_xml()
            try:
                result = self.tally_instance_id.send_and_process_tally(
                    url=product.tally_instance_id.url,
                    payload=payload,
                    process_log=process_log,
                    success_msg="Successfully Exported Stock Item",
                    error_msg="Failed to Export Stock Items"
                )
                if result.get('success'):
                    product.tally_response = result.get('raw_response')
                    product.tally_exported = True
                    product.tally_operation = 'export'
                else:
                    product.tally_response = result.get('raw_response')
            except Exception as e:
                product.tally_response = f"Error: {str(e)}"

    def generate_tally_product_xml(self):
        """
        Export product data from Odoo to Tally as <STOCKITEM> XML
        """
        self.ensure_one()
        product = self

        # Dynamic fields from Odoo
        product_name = product.display_name or "Unnamed Product"
        parent_group = product.categ_id.parent_id.name if product.categ_id.parent_id else ""
        category = product.categ_id.name or "General"
        base_unit = product.uom_id.name or "Nos"
        additional_unit = "&#4; Not Applicable"

        valuation_method = "Avg. Price"  # Can map from Odoo costing method
        is_active = "Yes" if product.active else "No"

        standard_price = f"{product.standard_price:.2f}/{base_unit}"
        list_price = f"{product.list_price:.2f}/{base_unit}"

        opening_balance = f"0 {base_unit}"
        opening_value = "0.00"

        # GST / HSN Code (assuming you have a field 'l10n_in_hsn_code')
        hsn_code = getattr(product, "l10n_in_hsn_code", "") or "NA"
        gst_applicable = "&#4; Applicable"

        # Generate unique GUID
        guid = str(uuid.uuid4())

        # Root
        envelope = ET.Element("ENVELOPE")
        header = ET.SubElement(envelope, "HEADER")
        ET.SubElement(header, "TALLYREQUEST").text = "Import Data"

        body = ET.SubElement(envelope, "BODY")
        importdata = ET.SubElement(body, "IMPORTDATA")

        requestdesc = ET.SubElement(importdata, "REQUESTDESC")
        ET.SubElement(requestdesc, "REPORTNAME").text = "All Masters"

        requestdata = ET.SubElement(importdata, "REQUESTDATA")
        tallymsg = ET.SubElement(requestdata, "TALLYMESSAGE", {"xmlns:UDF": "TallyUDF"})

        stockitem = ET.SubElement(tallymsg, "STOCKITEM", {
            "NAME": product_name,
            "ACTION": "Create"
        })

        ET.SubElement(stockitem, "GUID", {"TYPE": "String"}).text = guid
        ET.SubElement(stockitem, "PARENT", {"TYPE": "String"}).text = parent_group
        ET.SubElement(stockitem, "CATEGORY", {"TYPE": "String"}).text = category
        ET.SubElement(stockitem, "ISACTIVE", {"TYPE": "String"}).text = is_active
        ET.SubElement(stockitem, "VALUATIONMETHOD", {"TYPE": "String"}).text = valuation_method
        ET.SubElement(stockitem, "BASEUNITS", {"TYPE": "String"}).text = base_unit
        ET.SubElement(stockitem, "ADDITIONALUNITS", {"TYPE": "String"}).text = additional_unit
        ET.SubElement(stockitem, "OPENINGBALANCE", {"TYPE": "Quantity"}).text = opening_balance
        ET.SubElement(stockitem, "OPENINGVALUE", {"TYPE": "Amount"}).text = opening_value
        ET.SubElement(stockitem, "STANDARDCOST", {"TYPE": "Rate"}).text = standard_price
        ET.SubElement(stockitem, "STANDARDPRICE", {"TYPE": "Rate"}).text = list_price

        # GST Details
        ET.SubElement(stockitem, "GSTAPPLICABLE", {"TYPE": "String"}).text = gst_applicable
        gst_details = ET.SubElement(stockitem, "GSTDETAILS.LIST")
        ET.SubElement(gst_details, "APPLICABLEFROM").text = date.today().strftime("%Y%m%d")
        ET.SubElement(gst_details, "HSNMASTERNAME").text = hsn_code
        ET.SubElement(gst_details, "SRCOFGSTDETAILS").text = "Use GST Classification"
        ET.SubElement(gst_details, "GSTINELIGIBLEITC").text = "Yes"

        # Language Name
        lang_list = ET.SubElement(stockitem, "LANGUAGENAME.LIST")
        name_list = ET.SubElement(lang_list, "NAME.LIST", {"TYPE": "String"})
        ET.SubElement(name_list, "NAME").text = product_name
        ET.SubElement(lang_list, "LANGUAGEID", {"TYPE": "Number"}).text = "1033"

        # Final XML string
        xml_str = ET.tostring(envelope, encoding="utf-8", method="xml").decode("utf-8")
        xml_str = xml_str.replace("&amp;#4;", "&#4;")
        xml_str = xml_str.replace("\n", "").replace("\t", "").replace("  ", "")

        return xml_str

