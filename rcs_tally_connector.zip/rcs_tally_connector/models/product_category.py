from odoo import fields, models
from bs4 import BeautifulSoup


class ProductCategory(models.Model):
    _inherit = "product.category"

    external_id = fields.Char()
    fetch_from_tally = fields.Boolean()
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance")

    def build_product_category_request_xml(self):
        return """
        <ENVELOPE>
    <HEADER>
        <VERSION>1</VERSION>
        <TALLYREQUEST>Export</TALLYREQUEST>
        <TYPE>Collection</TYPE>
        <ID>List of Stock Categories</ID>
    </HEADER>
    <BODY>
        <DESC>
            <TDL>
                <TDLMESSAGE>
                    <COLLECTION NAME="List of Stock Categories" ISMODIFY="No">
                        <TYPE>Stock Category</TYPE>
                        <NATIVEMETHOD>Name</NATIVEMETHOD>
                        <NATIVEMETHOD>GUID</NATIVEMETHOD>
                        <NATIVEMETHOD>Parent</NATIVEMETHOD>
                        <NATIVEMETHOD>Alias</NATIVEMETHOD>
                    </COLLECTION>
                </TDLMESSAGE>
            </TDL>
        </DESC>
    </BODY>
</ENVELOPE>
"""

    def import_tally_product_categories(self, xml_response, instance):
        soup = BeautifulSoup(xml_response, "xml")
        collection = soup.find("COLLECTION")
        categories = collection.find_all("STOCKCATEGORY")
        for catg in categories:
            name = catg.NAME.text if catg.NAME else None
            guid = catg.GUID.text if catg.GUID else None
            parent_name = catg.PARENT.text if catg.PARENT else None

            parent_id = False
            if parent_name:
                parent = self.env["product.category"].search([("name", "=", parent_name)], limit=1)
                if parent:
                    parent_id = parent.id

            # Check if category already exists
            existing = self.env["product.category"].search([("name", "=", name)], limit=1)
            if existing:
                continue

            # Create new category
            self.env["product.category"].create({
                "name": name,
                "parent_id": parent_id,
                "external_id": guid,
                'tally_instance_id': instance.id,
                'fetch_from_tally': True,
            })
