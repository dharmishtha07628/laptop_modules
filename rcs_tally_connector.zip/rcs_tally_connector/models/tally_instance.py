import requests
import re
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
from requests.exceptions import ConnectionError, RequestException
from odoo import models, fields, api
from odoo.exceptions import UserError


class TallyInstance(models.Model):
    _name = "tally.instance"
    _description = "Tally Instance"

    name = fields.Char(string="Instance Name", required=True)
    url = fields.Char(string="Tally URL", required=True)

    auto_create_delivery = fields.Boolean(string="Auto Create Delivery")
    auto_create_receipt = fields.Boolean(string="Auto Create Receipt")
    auto_create_bill = fields.Boolean(string="Auto Create Bill")
    auto_create_invoice = fields.Boolean(string="Auto Create Invoice")
    state = fields.Selection([('draft', 'Draft'), ('connected', 'Connected'), ('not_connected', 'Not Connected')],
                             default='draft', string="Status")
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    voucher_type = fields.One2many('voucher.type', 'tally_instance_id', string="Voucher Type")
    fetch_locations = fields.Boolean(string="Fetch Locations")
    fetch_customers = fields.Boolean(string="Fetch Customers")
    fetch_products = fields.Boolean(string="Fetch Products")
    fetch_categories = fields.Boolean(string="Fetch Product Categories")
    fetch_accounts = fields.Boolean(string="Fetch Chart of Accounts")

    def fetch_voucher_types(self):
        url = self.url

        payload = """
          <ENVELOPE>
              <HEADER>
                  <VERSION>1</VERSION>
                  <TALLYREQUEST>Export</TALLYREQUEST>
                  <TYPE>Collection</TYPE>
                  <ID>List of Voucher Types</ID>
              </HEADER>
              <BODY>
                  <DESC/>
              </BODY>
          </ENVELOPE>
          """
        headers = {"Content-Type": "text/plain"}
        response = requests.post(url, headers=headers, data=payload)

        # Parse XML using BeautifulSoup
        soup = BeautifulSoup(response.text, "xml")
        data = soup.find("DATA")
        if not data:
            return
        collections = data.find('COLLECTION')
        if not collections:
            return

        voucher_ids = []
        for vtype in collections.find_all("VOUCHERTYPE"):
            name = vtype.get("NAME")
            if not name:
                continue

            # Check if voucher already exists for this instance
            vt_record = self.env["voucher.type"].search([
                ("name", "=", name),
                ("tally_instance_id", "=", self.id)
            ], limit=1)

            if not vt_record:
                # Create a new child record via One2many
                self.write({
                    "voucher_type": [(0, 0, {"name": name})]
                })

        return {
            "type": "ir.actions.client",
            "tag": "reload",
        }

    def tally_connect(self):
        """
        Try connecting to the given Tally instance URL.
        If connection is successful → state = connected
        If failed → state = not_connected
        """
        for rec in self:
            try:
                response = requests.get(rec.url)

                if response.status_code == 200 and "Tally" in response.text:
                    rec.state = "connected"
                else:
                    rec.state = "not_connected"

            except requests.exceptions.RequestException as e:
                rec.state = "not_connected"
                raise UserError(f"Failed to connect to Tally at {rec.url}\n\nError: {str(e)}")

    def action_fetch_locations(self):
        self.ensure_one()
        if not self.fetch_locations:
            raise UserError("Please enable 'Fetch Locations' to use this action.")
        self.fetch_master_details(model='stock.location')

    def action_fetch_customers(self):
        self.ensure_one()
        if not self.fetch_customers:
            raise UserError("Please enable 'Fetch Customers' to use this action.")
        self.fetch_master_details(model='res.partner')

    def action_fetch_products(self):
        self.ensure_one()
        if not self.fetch_products:
            raise UserError("Please enable 'Fetch Products' to use this action.")
        self.fetch_master_details(model='product.template')

    def action_fetch_categories(self):
        self.ensure_one()
        if not self.fetch_categories:
            raise UserError("Please enable 'Fetch Categories' to use this action.")
        self.fetch_master_details(model='product.category')

    def action_fetch_accounts(self):
        self.ensure_one()
        if not self.fetch_accounts:
            raise UserError("Please enable 'Fetch Accounts' to use this action.")
        self.fetch_master_details(model='account.account')

    def fetch_master_details(self, model):
        process_log = self.env['common.process.log'].create({
            'name': f"Tally Sync - {self.name}",
            'message': 'Started synchronization with Tally',
            'company_id': self.company_id.id,
            'res_model': 'tally.sync',
            'res_id': self.id,
        })
        try:
            xml_data = None
            url = self.url
            if model == 'res.partner':
                xml_data = """
    <ENVELOPE>
        <HEADER>
            <VERSION>1</VERSION>
            <TALLYREQUEST>Export</TALLYREQUEST>
            <TYPE>Collection</TYPE>
            <ID>LedgerDetails</ID>
        </HEADER>
        <BODY>
            <DESC>
                <TDL>
                    <TDLMESSAGE>
                        <COLLECTION NAME="LedgerDetails" ISMODIFY="No">
                            <TYPE>Ledger</TYPE>
                            <NATIVEMETHOD>Name</NATIVEMETHOD>
                            <NATIVEMETHOD>Parent</NATIVEMETHOD>
                            <NATIVEMETHOD>ClosingBalance</NATIVEMETHOD>
                        </COLLECTION>
                    </TDLMESSAGE>
                </TDL>
            </DESC>
        </BODY>
    </ENVELOPE>"""
            elif model == 'account.account':
                xml_data = self.env[model].prepare_xml_chart_of_accounts()
            elif model == 'product.template':
                xml_data = self.env[model].build_stock_request_xml()
            elif model == 'product.category':
                xml_data = self.env[model].build_product_category_request_xml()
            elif model == 'stock.location':
                xml_data = self.env[model].build_warehouse_request_xml()
            headers = {"Content-Type": "text/xml"}
            response = requests.post(url, data=xml_data, headers=headers)
            if response.status_code != 200:
                raise UserError("Tally Server Error: Response code %s" % response.status_code)
            cleaned_xml = response.content
            if model == 'res.partner':
                raw_xml = response.content.decode("utf-8", errors="ignore")

                # Remove invalid XML chars (ASCII control characters < 32 except tab, newline, carriage return)
                cleaned_xml = re.sub(
                    r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", raw_xml
                )

                soup = BeautifulSoup(cleaned_xml, "xml")
                collection = soup.find("COLLECTION")
                ledgers = collection.find_all("LEDGER")
                for ledger in ledgers:
                    name = ledger.NAME.text if ledger.NAME else ""
                    parent = ledger.PARENT.text if ledger.PARENT else ""
                    closing_balance = ledger.CLOSINGBALANCE.text if ledger.CLOSINGBALANCE else ""

                    if not name:
                        continue

                    vals = {
                        'name': name,
                        'company_type': 'company',
                        'customer_rank': 1,
                        'tally_instance_id': self.id,
                        'tally_operation': 'fetch'
                    }

                    if closing_balance:
                        vals['comment'] = f"Closing Balance: {closing_balance}, Parent: {parent}"

                    partner = self.env['res.partner'].search([
                        ('name', '=', name),
                        ('company_id', '=', self.env.company.id)
                    ], limit=1)

                    if not partner:
                        self.env['res.partner'].create(vals)
            elif model == 'product.template':
                self.env['product.template'].import_tally_stock_items(cleaned_xml, self)
            elif model == 'account.account':
                self.env['account.account'].import_tally_groups(cleaned_xml, self)
            elif model == 'product.category':
                self.env['product.category'].import_tally_product_categories(cleaned_xml, self)
            elif model == 'stock.location':
                self.env['stock.location'].with_context(company_id=self.company_id).import_tally_godowns(
                    cleaned_xml, self)

        except Exception as e:
            process_log.create_log_line(
                state="error",
                message=f"Failed to import voucher",
                response=str(e),
                res_model="tally.sync",
            )

    def send_and_process_tally(self, url, payload, process_log=None, success_msg=None, error_msg=None):
        """
        Send payload to Tally, parse response, and update record fields.
        """
        self.ensure_one()
        result = {
            "success": False,
            "created": 0,
            "altered": 0,
            "error_msg": None,
            "raw_response": "",
        }

        try:
            response = requests.post(url, headers={"Content-Type": "application/xml"}, data=payload)
            result["raw_response"] = response.text

            if not response.text:
                result["error_msg"] = "Empty response received from Tally."
            else:
                try:
                    root = ET.fromstring(response.text)
                    result["created"] = int(root.findtext("CREATED") or 0)
                    result["altered"] = int(root.findtext("ALTERED") or 0)
                except ET.ParseError as e:
                    result["error_msg"] = f"Invalid XML: {str(e)}"

            if result["created"] > 0 or result["altered"] > 0:
                result["success"] = True
                if process_log:
                    process_log.create_log_line(
                        state="success",
                        message=success_msg or "Successfully exported to Tally",
                        response=result["raw_response"],
                        res_model=self._name,
                    )
            else:
                if not result["error_msg"]:
                    result["error_msg"] = root.findtext("LINEERROR") or "Unknown error from Tally"
                if process_log:
                    process_log.create_log_line(
                        state="error",
                        message=error_msg or f"Failed to export to Tally: {result['error_msg']}",
                        response=result["raw_response"],
                        res_model=self._name,
                    )

        except ConnectionError:
            result["error_msg"] = "Could not connect to Tally. Please check if Tally is running and URL is correct."
        except RequestException as e:
            result["error_msg"] = f"Request error while exporting to Tally: {str(e)}"

        except Exception as e:
            result["error_msg"] = f"Unexpected error: {str(e)}"

        return result
