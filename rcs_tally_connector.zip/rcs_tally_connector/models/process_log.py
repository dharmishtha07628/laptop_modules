# -*- coding: utf-8 -*-
""" Create/Manage the Logs for process """
import logging
from odoo import models, api, fields, _

_LOGGER = logging.getLogger(">>> Common Process Logs <<<")

class CommonProcessLogs(models.Model):
    """
        Create/Manage the Logs for process
    """
    _inherit = "common.process.log"

    def create_log_line(self, state, message, response=None, res_model=None, res_id=None):
        """Helper to create log lines under this process log"""
        self.ensure_one()
        return self.env['common.process.log.lines'].create({
            'process_log_id': self.id,
            'state': state,
            'message': message,
            'response': response or '',
            'res_model': res_model or '',
            'res_id': res_id or False,
            'company_id': self.company_id.id,
        })