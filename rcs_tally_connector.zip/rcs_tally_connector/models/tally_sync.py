import requests
from lxml import etree
from odoo import models, fields, api, _
from odoo.exceptions import UserError, AccessError


class TallySync(models.Model):
    """
    Model for synchronizing data between Odoo and Tally.

    This model allows syncing various records such as Companies, Ledgers,
    Products, Sale/Purchase Orders, and generating Excel exports.
    It also computes record counts for sales and purchases within a date range.
    """
    _name = 'tally.sync'
    _description = 'Tally Data Synchronization'

    tally_instance_id = fields.Many2one('tally.instance', "Tally instance")

    name = fields.Char(
        string="Sync Name",
        required=True,
        help="A descriptive name for this sync operation."
    )
    url = fields.Char(
        string='Tally URL',
        default='http://localhost:9090',
        required=True,
        related='tally_instance_id.url',
        help="The URL endpoint of the Tally XML server."
    )
    voucher_type_id = fields.Many2one('voucher.type', domain="[('tally_instance_id','=',tally_instance_id)]",
                                      string="Voucher Type")

    result = fields.Text(
        string="Result",
        help="Raw text or message showing the result or logs of the sync process."
    )

    start_date = fields.Date(
        string="Start Date",
        default=fields.Date.today,
        help="Start date for filtering records (used mainly in reports or counts)."
    )
    end_date = fields.Date(
        string="End Date",
        default=fields.Date.today,
        help="End date for filtering records (used mainly in reports or counts)."
    )

    sale_order_count = fields.Integer(
        string="Sale Orders",
        compute="_compute_order_counts",
        store=False,
        help="Number of sale orders found in the specified date range."
    )
    purchase_order_count = fields.Integer(
        string="Purchase Orders",
        compute="_compute_order_counts",
        store=False,
        help="Number of purchase orders found in the specified date range."
    )
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    def _compute_order_counts(self):
        for rec in self:
            rec.sale_order_count = self.env['sale.order'].search_count([('tally_instance_id', '=', rec.id)])
            rec.purchase_order_count = self.env['purchase.order'].search_count([('tally_instance_id', '=', rec.id)])

    def action_view_sale_orders(self):
        return {
            'name': 'Sale Orders',
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order',
            'view_mode': 'list,form',
            'domain': [('tally_instance_id', '=', self.id)],
            'context': {'default_instance_id': self.id},
        }

    def action_view_purchase_orders(self):
        return {
            'name': 'Purchase Orders',
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.order',
            'view_mode': 'list,form',
            'domain': [('tally_instance_id', '=', self.id)],
            'context': {'default_instance_id': self.id},
        }

    def action_sync_data(self):
        """
          Main method to perform synchronization with Tally based on the selected model.
          It builds the appropriate XML request, sends it to the Tally server, parses the
        """
        for record in self:
            # Create a master process log
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {record.name}",
                'message': 'Started synchronization with Tally',
                'company_id': record.tally_instance_id.company_id.id,
                'res_model': 'tally.sync',
                'res_id': record.id,
            })
            try:
                xml_data = None
                url = record.url
                headers = {"Content-Type": "text/xml"}

                # Prepare XML based on selected model
                # if record.voucher_type_id.model_name.model == 'res.company':
                #     xml_data = record._build_company_request_xml()

                if record.voucher_type_id.model_name.model == 'sale.order':
                    xml_data = self.env['sale.order'].prepare_xml_sale(record)

                elif record.voucher_type_id.model_name.model == 'purchase.order':
                    xml_data = self.env['purchase.order'].prepare_xml_purchase(record)

                elif record.voucher_type_id.model_name.model == 'account.move':
                    if record.voucher_type_id.move_type in ['out_invoice', 'in_invoice', 'in_refund', 'out_refund',
                                                            'entry']:
                        xml_data = self.env['account.move'].prepare_xml_invoice(record, record.voucher_type_id)

                elif record.voucher_type_id.model_name.model == 'stock.picking':
                    xml_data = self.env['stock.picking'].prepare_xml_delivery(record, record.voucher_type_id)

                elif record.voucher_type_id.model_name.model == 'account.payment':
                    if record.voucher_type_id.is_customer_payment:
                        xml_data = self.env['account.payment'].prepare_xml_receipt(record, record.voucher_type_id,
                                                                                   customer=record.voucher_type_id.is_customer_payment)
                    elif record.voucher_type_id.is_vendor_payment:
                        xml_data = self.env['account.payment'].prepare_xml_receipt(record, record.voucher_type_id,
                                                                                   vendor=record.voucher_type_id.is_vendor_payment)

                if not xml_data:
                    process_log.create_log_line(
                        name="Tally Sync",
                        state="error",
                        message=f"No XML generated for model: {record.voucher_type_id.model_name.model}",
                        res_model=record.voucher_type_id.model_name.model,
                        res_id=record.id,
                    )
                    continue

                response = requests.post(url, data=xml_data, headers=headers)
                if response.status_code != 200:
                    process_log.create_log_line(
                        state="error",
                        message=f"Tally connection failed for {record.name}",
                        response=f"Status: {response.status_code}, Content: {response.text}",
                        res_model=record.voucher_type_id.model_name.model,
                        res_id=record.id,
                    )
                    raise UserError("Tally Server Error: Response code %s" % response.status_code)

                cleaned_xml = response.content

                process_log.create_log_line(
                    state="success",
                    message=f"Successfully synced {record.voucher_type_id.model_name.model} ({record.name})",
                    response=response.text[:2000],  # log first 2000 chars
                    res_model=record.voucher_type_id.model_name.model,
                    res_id=record.id,
                )

                # Parse and process data based on model
                if record.voucher_type_id.model_name.model == 'res.company':
                    tree = etree.fromstring(response.content)
                    companies = tree.xpath('//COLLECTION/COMPANY')
                    for company in companies:
                        name = company.get('NAME') or company.findtext('NAME')
                        if not name:
                            continue
                        name = name.strip()
                        existing = self.env['res.company'].search([('name', '=', name)], limit=1)
                        if existing:
                            existing.write({
                                'name': name,
                            })
                        else:
                            # Create new company
                            self.env['res.company'].create({
                                'name': name,
                            })

                elif record.voucher_type_id.model_name.model == 'sale.order':
                    self.env['sale.order'].with_context(instance_id=record.id).import_tally_sales_orders(cleaned_xml,
                                                                                                         self.tally_instance_id)

                elif record.voucher_type_id.model_name.model == 'purchase.order':
                    self.env['purchase.order'].with_context(instance_id=record.id).import_tally_purchase_orders(
                        cleaned_xml, self.tally_instance_id)

                elif record.voucher_type_id.model_name.model == 'account.move':
                    move_type = record.voucher_type_id.move_type
                    self.env['account.move'].import_tally_invoice_voucher(cleaned_xml, self, move_type=move_type)

                elif record.voucher_type_id.model_name.model == 'account.payment':
                    if record.voucher_type_id.is_customer_payment:
                        self.result = cleaned_xml
                        self.env['account.payment'].with_context(instance_id=record.id).import_tally_receipt_vouchers(
                            cleaned_xml, self.tally_instance_id, customer=True)
                    elif record.voucher_type_id.is_vendor_payment:
                        self.result = cleaned_xml
                        self.env['account.payment'].with_context(instance_id=record.id).import_tally_receipt_vouchers(
                            cleaned_xml, self.tally_instance_id, vendor=True)
                elif record.voucher_type_id.model_name.model == 'stock.picking':
                    self.env['stock.picking'].import_tally_material_in_out(cleaned_xml, self.tally_instance_id,
                                                                           self.voucher_type_id)
            except Exception as e:
                process_log.create_log_line(
                    state="error",
                    message=f"Failed to import voucher",
                    response=str(e),
                    res_model="tally.sync",
                )
                raise UserError(f"Tally Connection Failed: {str(e)}")

#     def _build_company_request_xml(self):
#         return """
# <ENVELOPE>
# 	<HEADER>
# 		<VERSION>1</VERSION>
# 		<TALLYREQUEST>Export</TALLYREQUEST>
# 		<TYPE>Collection</TYPE>
# 		<ID>List of Companies</ID>
# 	</HEADER>
# 	<BODY>
# 		<DESC>
# 			<STATICVARIABLES>
#             <SVIsSimpleCompany>No</SVIsSimpleCompany>
#             </STATICVARIABLES>
# 			<TDL>
# 				<TDLMESSAGE>
# 					<COLLECTION ISMODIFY="No" ISFIXED="No" ISINITIALIZE="Yes" ISOPTION="No" ISINTERNAL="No" NAME="List of Companies">
# 						<TYPE>Company</TYPE>
# 						<NATIVEMETHOD>Name</NATIVEMETHOD>
# 					</COLLECTION>
#                     <ExportHeader>EmpId:5989</ExportHeader>
# 				</TDLMESSAGE>
# 			</TDL>
# 		</DESC>
# 	</BODY>
# </ENVELOPE>
#         """
