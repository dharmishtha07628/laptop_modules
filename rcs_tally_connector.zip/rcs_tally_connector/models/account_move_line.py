import logging
import re
from odoo import api, fields, models, _
_logger = logging.getLogger(__name__)


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    def prepare_move_lines_from_voucher(self, voucher, move_type):
        order_lines = []
        if move_type != 'entry':
            inventory_entries = voucher.find_all("ALLINVENTORYENTRIES.LIST")

            for entry in inventory_entries:
                item_name = entry.find("STOCKITEMNAME")
                GSTHSNNAME = entry.find('GSTHSNNAME') or 99999
                description = entry.find("DESCRIPTION")
                is_deemed_positive = entry.find("ISDEEMEDPOSITIVE").text if entry.find("ISDEEMEDPOSITIVE") else "No"
                if not item_name or not item_name.text.strip():
                    continue

                name = item_name.text.strip()

                # Parse quantity
                billed_qty_tag = entry.find("BILLEDQTY")
                qty = 1.0
                if billed_qty_tag and billed_qty_tag.text.strip():
                    try:
                        qty = float(billed_qty_tag.text.strip().split(" ")[0])
                    except ValueError:
                        qty = 1.0

                # Parse rate
                rate_tag = entry.find("RATE")
                rate = 0.0
                if rate_tag and rate_tag.text.strip():
                    try:
                         rate = float(rate_tag.text.strip().split("/")[0])
                    except ValueError:
                        rate = 0.0

                # 🔍 Extract GST Tax
                tax = self._extract_gst_tax(entry, move_type)

                # 🔍 Get or Create Product
                product = self.env['product.product'].search([('name', '=', name)], limit=1)
                if not product:
                    product = self.env['product.product'].create({
                        'name': name,
                        'lst_price': rate,
                        'type': 'consu',
                        'is_storable': True,
                        'l10n_in_hsn_code': GSTHSNNAME.text or ''
                    })

                discount = entry.DISCOUNT
                if discount:
                    if isinstance(discount, str):
                        discount = float(discount.text)
                    else:
                        discount = float(discount.text)

                line_vals = {
                    'product_id': product.id,
                    'quantity': qty,
                    'price_unit': rate,
                    'discount': discount if discount else 0.0,
                }
                if tax:
                    line_vals['tax_ids'] = [(6, 0, [tax.id])]

                order_lines.append((0, 0, line_vals))
        else:
            ledger_entries = voucher.find_all("ALLLEDGERENTRIES.LIST")

            for entry in ledger_entries:
                ledger_name = entry.find("LEDGERNAME").text if entry.find("LEDGERNAME") else None
                amount_tag = entry.find("AMOUNT")
                is_deemed_positive = entry.find("ISDEEMEDPOSITIVE").text if entry.find("ISDEEMEDPOSITIVE") else "No"

                if not ledger_name or not amount_tag or not amount_tag.text.strip():
                    continue

                try:
                    amount = float(amount_tag.text.strip())
                except ValueError:
                    amount = 0.0

                # Lookup or create account
                account = self.env['account.account'].search([
                    ('name', '=', ledger_name),
                    ('company_ids', 'in', self.env.company.ids)
                ], limit=1)

                if not account:
                    account = self.env['account.account'].create({
                        'name': ledger_name,
                        'code': self._generate_code(ledger_name),
                        'account_type': 'expense' if amount < 0 else 'income',
                        'company_ids': self.env.company.ids,
                    })

                line_vals = {
                    'account_id': account.id,
                    'debit': abs(amount) if is_deemed_positive == "Yes" else 0.0,
                    'credit': abs(amount) if is_deemed_positive == "No" else 0.0,
                    'name': ledger_name,
                }

                order_lines.append((0, 0, line_vals))

        return order_lines

    def _generate_code(self, name):
        # Keep only alphanumeric characters and dots
        clean_name = re.sub(r'[^A-Za-z0-9.]', '', name[:64])
        return clean_name.upper()

    def _extract_gst_tax(self, inventory_entry, move_type):
        import re

        gst_source_tag = inventory_entry.find("GSTLEDGERSOURCE")
        if not gst_source_tag or not gst_source_tag.text:
            return None

        text = gst_source_tag.text.strip().upper()

        gst_type = None
        gst_rate = 0.0

        # Detect GST type
        if "IGST" in text:
            gst_type = "IGST"
        elif "GST" in text:
            gst_type = "GST"  # catch all GST cases
        else:
            return None

        # Extract GST rate
        match = re.search(r'(\d+(\.\d+)?)\s*%', text)
        if match:
            try:
                gst_rate = float(match.group(1))
            except ValueError:
                return None

        # Build tax name dynamically
        if gst_type == "IGST":
            tax_name = f"{int(gst_rate)}% IGST"
        else:
            tax_name = f"{int(gst_rate)}% GST"

        # Adjust usage type based on move_type
        if move_type in ("out_invoice", "out_refund"):
            tax_use = "sale"
        else:  # in_invoice, in_refund
            tax_use = "purchase"

        # Search in account.tax
        tax = self.env['account.tax'].search([
            ('type_tax_use', '=', tax_use),
            ('amount', '=', gst_rate),
            ('company_id', '=', self.env.company.id),
            ('name', 'ilike', tax_name),  # looser match
        ], limit=1)

        if not tax:
            _logger.warning("❌ No matching %s tax found for GST Source: %s → Wanted: %s",
                            tax_use, text, tax_name)
        else:
            _logger.info("✅ Selected %s Tax: %s", tax_use.capitalize(), tax.name)

        return tax
