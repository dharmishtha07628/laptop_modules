import re
from odoo import api, fields, models, _
from odoo.exceptions import AccessError
import xml.etree.ElementTree as ET
from datetime import datetime
from bs4 import BeautifulSoup


class purchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"

    def _prepare_order_lines_from_voucher(self, voucher):
        order_lines = []
        inventory_entries = voucher.find_all("ALLINVENTORYENTRIES.LIST")

        for entry in inventory_entries:
            item_name = entry.find("STOCKITEMNAME")
            GSTHSNNAME = entry.find('GSTHSNNAME') or 99999
            description = entry.find("DESCRIPTION")
            if not item_name or not item_name.text.strip():
                continue

            name = item_name.text.strip()

            # Parse quantity
            billed_qty_tag = entry.find("BILLEDQTY")
            qty = 1.0
            if billed_qty_tag and billed_qty_tag.text.strip():
                try:
                    qty = float(billed_qty_tag.text.strip().split(" ")[0])
                except ValueError:
                    qty = 1.0

            # Parse rate
            rate_tag = entry.find("RATE")
            rate = 0.0
            if rate_tag and rate_tag.text.strip():
                try:
                    rate = float(rate_tag.text.strip().split("/")[0])
                except ValueError:
                    rate = 0.0

            # 🔍 Extract GST Tax
            tax = self._extract_gst_tax(entry)

            # 🔍 Get or Create Product
            product = self.env['product.product'].search([('name', '=', name)], limit=1)
            if not product:
                product = self.env['product.product'].create({
                    'name': name,
                    'lst_price': rate,
                    'type': 'consu',
                    'is_storable': True,
                    'l10n_in_hsn_code': GSTHSNNAME.text or ''
                })

            discount = entry.DISCOUNT
            if discount:
                if isinstance(discount, str):
                    discount = float(discount.text)
                else:
                    discount = float(discount.text)

            line_vals = {
                'product_id': product.id,
                'product_qty': qty,
                'price_unit': rate,

                'discount': discount if discount else 0.0,
            }
            if tax:
                line_vals['taxes_id'] = [(6, 0, [tax.id])]

            order_lines.append((0, 0, line_vals))

        return order_lines

    def _extract_gst_tax(self, inventory_entry):
        import re

        gst_source_tag = inventory_entry.find("GSTLEDGERSOURCE")
        if not gst_source_tag or not gst_source_tag.text:
            return None

        text = gst_source_tag.text.strip().upper()

        gst_type = None
        gst_rate = 0.0

        # Detect GST type
        if "IGST" in text:
            gst_type = "IGST"
        elif "SALES GST" in text:
            gst_type = "GST_S"  # Specific type for your case
        else:
            return None

        # Extract GST rate
        match = re.search(r'(\d+(\.\d+)?)\s*%', text)
        if match:
            try:
                gst_rate = float(match.group(1))
            except ValueError:
                return None

        # Build exact name
        if gst_type == "IGST":
            tax_name = f"{int(gst_rate)}% IGST S"
        else:  # GST_S
            tax_name = f"{int(gst_rate)}% GST S"

        tax = self.env['account.tax'].search([
            ('type_tax_use', '=', 'sale'),
            ('amount', '=', gst_rate),
            ('company_id', '=', self.env.company.id),
            ('name', '=', tax_name),  # Strict match
        ], limit=1)

        if not tax:
            print(f"❌ No matching tax found for GST Source: {text} → Wanted: {tax_name}")
        else:
            print(f"✅ Selected Tax: {tax.name}")

        return tax
