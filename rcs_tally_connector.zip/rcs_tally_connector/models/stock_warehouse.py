import re
from odoo import api, fields, models, _
from odoo.exceptions import AccessError
import xml.etree.ElementTree as ET
from datetime import datetime
from bs4 import BeautifulSoup

class Stocklocation(models.Model):
    _inherit = 'stock.location'

    external_id = fields.Char()
    fetch_from_tally = fields.Boolean()
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance")

    def build_warehouse_request_xml(self):
        return """
        <ENVELOPE>
    <HEADER>
        <VERSION>1</VERSION>
        <TALLYREQUEST>Export</TALLYREQUEST>
        <TYPE>Collection</TYPE>
        <ID>List of Godowns</ID>
    </HEADER>
    <BODY>
        <DESC>
            <TDL>
                <TDLMESSAGE>
                    <COLLECTION NAME="List of Godowns" ISMODIFY="No">
                        <TYPE>Godown</TYPE>
                        <NATIVEMETHOD>Name</NATIVEMETHOD>
                        <NATIVEMETHOD>GUID</NATIVEMETHOD>
                        <NATIVEMETHOD>Parent</NATIVEMETHOD>
                        <NATIVEMETHOD>Alias</NATIVEMETHOD>
                    </COLLECTION>
                </TDLMESSAGE>
            </TDL>
        </DESC>
    </BODY>
</ENVELOPE>
"""

    def import_tally_godowns(self, xml_response, instance):
        soup = BeautifulSoup(xml_response, "xml")
        collection = soup.find("COLLECTION")
        godowns = collection.find_all("GODOWN")

        company_id = self.env.context.get("company_id").id or self.env.company.id
        odoo_company = self.env["res.company"].browse(company_id)

        # Find default warehouse stock location for this company
        warehouse = self.env["stock.warehouse"].search([("company_id", "=", odoo_company.id)], limit=1)
        company_stock_location = warehouse.lot_stock_id

        for godown in godowns:
            name = godown.NAME.text if godown.NAME else None
            guid = godown.GUID.text if godown.GUID else None
            parent_name = godown.PARENT.text if godown.PARENT else None

            parent_id = False
            if parent_name and parent_name != "Primary":
                parent = self.env["stock.location"].search([
                    ("name", "=", parent_name),
                    ("company_id", "=", odoo_company.id)
                ], limit=1)
                parent_id = parent.id if parent else False

            store = self.env["stock.location"].search([
                ("external_id", "=", guid),
                ("company_id", "=", odoo_company.id)
            ], limit=1)

            vals = {
                "name": name,
                "location_id": parent_id or company_stock_location.id,
                "usage": "internal",
                "external_id": guid,
                "company_id": odoo_company.id,
                'tally_instance_id':instance.id,
            }

            if not store:
                self.env["stock.location"].create(vals)
            else:
                store.write(vals)

