import logging
from odoo import api, fields, models, _
import uuid
import xml.etree.ElementTree as ET
from odoo.exceptions import AccessError, UserError
from bs4 import BeautifulSoup

_logger = logging.getLogger(__name__)


class StockPicking(models.Model):
    _inherit = "stock.picking"

    guid = fields.Char()
    tally_operation = fields.Selection([
        ('fetch', 'Fetch from Tally'),
        ('export', 'Export to Tally'),
        ('none', 'No Action')
    ], default='none')
    tally_voucher_key = fields.Char()
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance", )
    tally_response = fields.Text(string="Tally Response")
    tally_exported = fields.Boolean()
    voucher_type_id = fields.Many2one('voucher.type', domain="[('tally_instance_id','=',tally_instance_id)]",
                                      string="Voucher Type")

    def prepare_xml_delivery(self, invoice, vouchar, **kwargs):
        xml_request = f"""
          <ENVELOPE>
     <HEADER>
       <TALLYREQUEST>Export Data</TALLYREQUEST>
     </HEADER>
     <BODY>
       <EXPORTDATA>
         <REQUESTDESC>
           <REPORTNAME>Voucher Register</REPORTNAME>
           <STATICVARIABLES>
             <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
             <VOUCHERTYPENAME>{vouchar.name}</VOUCHERTYPENAME>
           </STATICVARIABLES>
         </REQUESTDESC>
         <REQUESTDATA>
           <TALLYMESSAGE>
             <COLLECTION ISMODIFY="No">
               <TYPE>Voucher</TYPE>
               <NATIVEMETHOD>VoucherNumber</NATIVEMETHOD>
               <NATIVEMETHOD>Date</NATIVEMETHOD>
               <NATIVEMETHOD>VoucherTypeName</NATIVEMETHOD>
               <NATIVEMETHOD>PartyLedgerName</NATIVEMETHOD>
               <NATIVEMETHOD>Narration</NATIVEMETHOD>
               <NATIVEMETHOD>ALLLEDGERENTRIES.LIST</NATIVEMETHOD>
             </COLLECTION>
           </TALLYMESSAGE>
         </REQUESTDATA>
       </EXPORTDATA>
     </BODY>
   </ENVELOPE>"""

        return xml_request

    def import_tally_material_in_out(self, cleaned_xml, tally_instance_id, voucher_type_id):
        process_log = self.env['common.process.log'].create({
            'name': f"Tally Import - {voucher_type_id.name}",
            'message': 'Started importing vouchers',
            'company_id': tally_instance_id.company_id.id,
            'res_model': 'stock.picking',
        })

        soup = BeautifulSoup(cleaned_xml, "xml")
        all_inv_vochers = soup.find_all('TALLYMESSAGE')
        for voc in all_inv_vochers:
            try:
                voucher_number = voc.VOUCHERNUMBER.text if voc.VOUCHERNUMBER else False
                voucher_date = voc.DATE.text if voc.DATE else False
                party_name = voc.PARTYNAME.text if voc.PARTYNAME else ''
                source_godown = voc.VOUCHERSOURCEGODOWN.text if voc.VOUCHERSOURCEGODOWN else False
                destination_godown = voc.DESTINATIONGODOWN.text if voc.DESTINATIONGODOWN else False

                # Convert Tally date (YYYYMMDD) to Python date
                picking_date = False
                if voucher_date:
                    picking_date = f"{voucher_date[:4]}-{voucher_date[4:6]}-{voucher_date[6:8]}"


                # Prepare picking values
                picking_vals = {
                    'partner_id': self.env['res.partner'].search([('name', '=', party_name)], limit=1).id,
                    'picking_type_id': voucher_type_id.picking_type_id.id,
                    'scheduled_date': picking_date,
                    'origin': voucher_number,
                    'tally_instance_id': tally_instance_id.id,
                    'tally_guid': voc.GUID.text if voc.GUID else ''
                }
                # Create picking
                picking = self.env['stock.picking'].create(picking_vals)
                if source_godown:
                    picking.location_id = self._get_source_location(source_godown)
                if destination_godown:
                    picking.location_dest_id = self._get_dest_location(destination_godown)
                if voucher_type_id.picking_type_id.code == 'outgoing':
                    inventoies = voc.find_all("INVENTORYENTRIESOUT.LIST")
                else:
                    inventoies = voc.find_all("INVENTORYENTRIESIN.LIST")
                if inventoies:
                    for entry in inventoies:
                        product_name = entry.STOCKITEMNAME.text if entry.STOCKITEMNAME else ""
                        quantity = float(entry.BILLEDQTY.text.split()[0]) if entry.BILLEDQTY else 1.0
                        rate_text = entry.RATE
                        try:
                            rate = float(rate_text.text.split("/")[0]) if entry.RATE else 0.0
                        except ValueError:
                            rate = 0.0

                        # Get or create product
                        product = self.env['product.product'].search([('name', '=', product_name)], limit=1)
                        if not product:
                            product = self.env['product.product'].create({
                                'name': product_name,
                                'lst_price': rate,
                                'type': 'consu',
                                'is_storable': True,
                            })

                        # Create move line
                        self.env['stock.move'].create({
                            'name': product.name,
                            'product_id': product.id,
                            'product_uom_qty': quantity,
                            'product_uom': product.uom_id.id,
                            'picking_id': picking.id,
                            'location_id': picking.location_id.id,
                            'location_dest_id': picking.location_dest_id.id,
                            'price_unit': rate,
                        })
            except Exception as e:
                process_log.create_log_line(
                    state="error",
                    message=f"Failed to import voucher",
                    response=str(e),
                    res_model="stock.picking",
                )

    def _get_source_location(self, location_name):
        location = self.env['stock.location'].search([('name', '=', location_name)], limit=1)
        return location.id

    def _get_dest_location(self, location_name):
        location = self.env['stock.location'].search([('name', '=', location_name)], limit=1)
        return location.id


    def export_in_tally(self):
        """
        Send Sale Order to Tally on button click
        """
        for transfer in self:
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {transfer.name}",
                'message': 'Material in/Out order Export to Tally initiated.',
                'company_id': transfer.tally_instance_id.company_id.id,
                'res_model': 'stock.picking ',
                'res_id': transfer.id,
            })
            self.ensure_one()
            if not transfer.tally_instance_id or not transfer.tally_instance_id.url:
                raise UserError("No Tally instance URL configured.")

            payload = transfer.generate_tally_xml()

            try:
                result = self.tally_instance_id.send_and_process_tally(
                    url=transfer.tally_instance_id.url,
                    payload=payload,
                    process_log=process_log,
                    success_msg="Successfully Exported Material in out Voucher",
                    error_msg="Failed to Export Sale Voucher"
                )
                if result.get('success'):
                    transfer.tally_response = result.get('raw_response')
                    transfer.tally_exported = True
                    transfer.tally_operation = 'export'
                else:
                    transfer.tally_response = result.get('raw_response')
            except Exception as e:
                process_log.create_log_line(
                    state="error",
                    message=f"Failed to Export sale voucher",
                    response=str(e ),
                    res_model="stock.picking",
                )
                transfer.tally_response = f"Error: {str(e)}"
    
    def  generate_tally_xml(self):
        """
               Generate Tally Material In Voucher XML from stock.picking record.
               Works for incoming transfers.
               """
        self.ensure_one()

        if self.picking_type_code not in ('incoming', 'outgoing'):
            return None

        # Generate unique GUID for voucher
        guid = str(uuid.uuid4())

        # Dates
        pick_date = self.scheduled_date or fields.Datetime.now()
        date_str = pick_date.strftime('%Y%m%d')

        # Partner
        partner_name = self.partner_id.name or "Unknown Partner"
        state_name = self.partner_id.state_id.name or ""

        # Godown
        godown_name = self.location_dest_id.name if self.picking_type_code == "incoming" else self.location_id.name

        # Voucher type
        vch_type = "Material In" if self.picking_type_code == "incoming" else "Material Out"
        inv_tag = "INVENTORYENTRIESIN.LIST" if self.picking_type_code == "incoming" else "INVENTORYENTRIESOUT.LIST"
        deemed_positive = "Yes" if self.picking_type_code == "incoming" else "Yes"

        # Envelope
        envelope = ET.Element("ENVELOPE")
        header = ET.SubElement(envelope, "HEADER")
        ET.SubElement(header, "TALLYREQUEST").text = "Import Data"

        body = ET.SubElement(envelope, "BODY")
        importdata = ET.SubElement(body, "IMPORTDATA")
        reqdesc = ET.SubElement(importdata, "REQUESTDESC")
        ET.SubElement(reqdesc, "REPORTNAME").text = "Vouchers"
        reqdata = ET.SubElement(importdata, "REQUESTDATA")

        tallymsg = ET.SubElement(reqdata, "TALLYMESSAGE", attrib={"xmlns:UDF": "TallyUDF"})
        voucher = ET.SubElement(tallymsg, "VOUCHER", attrib={"VCHTYPE": vch_type, "ACTION": "Create"})

        ET.SubElement(voucher, "DATE").text = date_str
        ET.SubElement(voucher, "VOUCHERTYPENAME").text = vch_type
        ET.SubElement(voucher, "PARTYNAME").text = partner_name
        ET.SubElement(voucher, "PARTYLEDGERNAME").text = partner_name
        ET.SubElement(voucher, "BASICBUYERNAME").text = partner_name
        ET.SubElement(voucher, "PARTYMAILINGNAME").text = partner_name
        ET.SubElement(voucher, "EFFECTIVEDATE").text = date_str
        ET.SubElement(voucher, "REFERENCEDATE").text = date_str
        ET.SubElement(voucher, "GUID").text = guid
        ET.SubElement(voucher, "STATENAME").text = state_name
        ET.SubElement(voucher, "PERSISTEDVIEW").text = "Multi Consumption Voucher View"
        ET.SubElement(voucher, "NUMBERINGSTYLE").text = "Auto Renumber"
        ET.SubElement(voucher, "NARRATION").text = f"{vch_type} transfer {self.name} from Odoo"
        ET.SubElement(voucher, "DESTINATIONGODOWN").text = godown_name
        ET.SubElement(voucher, "VOUCHERDESTINATIONGODOWN").text = godown_name

        # Ledger entry
        ledger = ET.SubElement(voucher, "LEDGERENTRIES.LIST")
        oldaudit = ET.SubElement(ledger, "OLDAUDITENTRYIDS.LIST", attrib={"TYPE": "Number"})
        ET.SubElement(oldaudit, "OLDAUDITENTRYIDS").text = "-1"
        ET.SubElement(ledger, "LEDGERNAME").text = partner_name
        ET.SubElement(ledger, "GSTCLASS").text = "Not Applicable"
        ET.SubElement(ledger, "ISDEEMEDPOSITIVE").text = deemed_positive
        ET.SubElement(ledger, "ISPARTYLEDGER").text = "Yes"
        ET.SubElement(ledger, "AMOUNT").text = "0.0"

        for move in self.move_ids_without_package:
            stock_item = move.product_id.display_name
            qty = move.product_uom_qty
            uom = move.product_uom.name or "NO"
            rate = move.product_id.standard_price or 0.0
            amount = -(qty * rate) if self.picking_type_code == "incoming" else (qty * rate)

            inv = ET.SubElement(voucher, inv_tag)

            # Description
            desc = ET.SubElement(inv, "BASICUSERDESCRIPTION.LIST", attrib={"TYPE": "String"})
            ET.SubElement(desc, "BASICUSERDESCRIPTION").text = self.name

            # Core stock details
            ET.SubElement(inv, "STOCKITEMNAME").text = stock_item
            ET.SubElement(inv, "HSNITEMSOURCE").text = stock_item
            ET.SubElement(inv, "HSNSOURCETYPE").text = "Stock Item"

            # --- Static fields for GST / compliance ---
            ET.SubElement(inv, "GSTRATEINFERAPPLICABILITY").text = "As per Masters/Company"
            ET.SubElement(inv, "GSTHSNINFERAPPLICABILITY").text = "As per Masters/Company"
            ET.SubElement(inv, "GSTOVRDNTYPEOFSUPPLY").text = "Goods"
            ET.SubElement(inv, "GSTHSNNAME").text = "84749000"
            ET.SubElement(inv, "GSTHSNDESCRIPTION").text = "84749000"
            ET.SubElement(inv, "GSTSOURCETYPE").text = "Stock Item"
            ET.SubElement(inv, "ISGSTASSESSABLEVALUEOVERRIDDEN").text = "No"
            ET.SubElement(inv, "STRDISGSTAPPLICABLE").text = "No"
            ET.SubElement(inv, "CONTENTNEGISPOS").text = "No"
            ET.SubElement(inv, "ISLASTDEEMEDPOSITIVE").text = "Yes"
            ET.SubElement(inv, "ISAUTONEGATE").text = "No"
            ET.SubElement(inv, "ISCUSTOMSCLEARANCE").text = "No"
            ET.SubElement(inv, "ISTRACKCOMPONENT").text = "No"
            ET.SubElement(inv, "ISTRACKPRODUCTION").text = "No"
            ET.SubElement(inv, "ISPRIMARYITEM").text = "No"
            ET.SubElement(inv, "ISSCRAP").text = "No"

            # Amount and quantities
            ET.SubElement(inv, "ISDEEMEDPOSITIVE").text = deemed_positive
            ET.SubElement(inv, "RATE").text = f"{rate:.2f}/{uom}"
            ET.SubElement(inv, "AMOUNT").text = f"{amount:.2f}"
            ET.SubElement(inv, "ACTUALQTY").text = f"{qty:.3f} {uom}"
            ET.SubElement(inv, "BILLEDQTY").text = f"{qty:.3f} {uom}"

            # Batch allocation (still dynamic)
            batch = ET.SubElement(inv, "BATCHALLOCATIONS.LIST")
            ET.SubElement(batch, "GODOWNNAME").text = godown_name
            ET.SubElement(batch, "BATCHNAME").text = "Primary Batch"
            ET.SubElement(batch, "DESTINATIONGODOWNNAME").text = godown_name
            ET.SubElement(batch, "ORDERNO").text = "Not Applicable"
            ET.SubElement(batch, "TRACKINGNUMBER").text = "Not Applicable"
            ET.SubElement(batch, "AMOUNT").text = f"{amount:.2f}"
            ET.SubElement(batch, "ACTUALQTY").text = f"{qty:.2f} {uom}"
            ET.SubElement(batch, "BILLEDQTY").text = f"{qty:.2f} {uom}"

        # Convert to string
        xml_str = ET.tostring(envelope, encoding="utf-8", method="xml").decode("utf-8")
        return xml_str