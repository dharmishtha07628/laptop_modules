import re
import requests
from lxml import etree
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import xmltodict


class ResPartner(models.Model):
    _inherit = "res.partner"

    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance", help="Tally instance associated with this partner")
    created_in_tally = fields.Integer(string="Created in Tally", default=0)
    altered_in_tally = fields.Integer(string="Altered in Tally", default=0)
    deleted_in_tally = fields.Integer(string="Deleted in Tally", default=0)
    last_vch_id_tally = fields.Integer(string="Last Voucher ID", default=0)
    last_mid_tally = fields.Integer(string="Last MID", default=0)
    combined_in_tally = fields.Integer(string="Combined in Tally", default=0)
    ignored_in_tally = fields.Integer(string="Ignored in Tally", default=0)
    errors_in_tally = fields.Integer(string="Errors in Tally", default=0)
    cancelled_in_tally = fields.Integer(string="Cancelled in Tally", default=0)
    exceptions_in_tally = fields.Integer(string="Exceptions in Tally", default=0)
    tally_response = fields.Text(string="Tally Response")
    tally_operation = fields.Selection([
        ('fetch', 'Fetch from Tally'),
        ('export', 'Export to Tally'),
        ('none', 'No Action')
    ], default='none')
    tally_exported = fields.Boolean()


    def search_partner(self, voucher):
        customer_name = voucher.PARTYNAME.text.strip() if voucher.find("PARTYNAME") else "Tally Customer"
        partner = self.env['res.partner'].search([('name', '=', customer_name)], limit=1)
        if not partner:
            partner = self.env['res.partner'].create({'name': customer_name})
        return partner

    def export_in_tally(self):
        for partner in self:
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {partner.name}",
                'message': 'Partner/customer Export to Tally initiated.',
                'company_id': partner.tally_instance_id.company_id.id,
                'res_model': 'res.partner',
                'res_id': partner.id,
            })
            if not partner.tally_instance_id or not partner.tally_instance_id.url:
                raise UserError("No Tally instance URL configured.")

            payload = partner.build_tally_ledger()
            try:
                result = self.tally_instance_id.send_and_process_tally(
                    url=partner.tally_instance_id.url,
                    payload=payload,
                    process_log=process_log,
                    success_msg="Successfully Exported Stock Item",
                    error_msg="Failed to Export Stock Items"
                )
                if result.get('success'):
                    partner.tally_response = result.get('raw_response')
                    partner.tally_exported = True
                    partner.tally_operation = 'export'
                    partner.process_tally_response(partner.tally_response)
                else:
                    partner.tally_response = result.get('raw_response')
            except Exception as e:
                partner.tally_response = f"Error: {str(e)}"

    def build_tally_ledger(self):
        envelope = etree.Element("ENVELOPE")

        # HEADER
        header = etree.SubElement(envelope, "HEADER")
        tallyrequest = etree.SubElement(header, "TALLYREQUEST")
        tallyrequest.text = "Import Data"

        # BODY
        body = etree.SubElement(envelope, "BODY")
        importdata = etree.SubElement(body, "IMPORTDATA")

        # REQUESTDESC
        requestdesc = etree.SubElement(importdata, "REQUESTDESC")
        reportname = etree.SubElement(requestdesc, "REPORTNAME")
        reportname.text = "All Masters"

        staticvars = etree.SubElement(requestdesc, "STATICVARIABLES")
        company = etree.SubElement(staticvars, "SVCURRENTCOMPANY")
        company.text = self.tally_instance_id.company_id.name  # fixed spelling

        # REQUESTDATA
        requestdata = etree.SubElement(importdata, "REQUESTDATA")
        address = self.street or '' + self.street2 or '' + self.city or '' + (self.state_id.name if self.state_id else '') + (self.zip or '')

        # TALLYMESSAGE with namespace
        tallymsg = etree.SubElement(requestdata, "TALLYMESSAGE", nsmap={"UDF": "TallyUDF"})

        ledger = etree.SubElement(tallymsg, "LEDGER", attrib={"NAME": self.name, "RESERVEDNAME": ""})
        etree.SubElement(ledger, "NAME").text = self.name
        etree.SubElement(ledger, "PARENT").text = "Sundry Debtors"
        etree.SubElement(ledger, "ISBILLWISEON").text = "Yes"
        etree.SubElement(ledger, "GSTREGISTRATIONTYPE").text = "Regular"
        etree.SubElement(ledger, "ADDRESS").text = address
        etree.SubElement(ledger, "PARTYGSTIN").text = self.vat or ''
        etree.SubElement(ledger, "COUNTRYNAME").text = self.country_id.name if self.country_id else "India"
        etree.SubElement(ledger, "STATE").text = self.state_id.name if self.state_id else ""

        # Return clean XML string (not escaped)
        return etree.tostring(envelope, pretty_print=True, xml_declaration=True, encoding="utf-8").decode("utf-8")

    def process_tally_response(self, resp):
        """
        Update partner with full Tally response fields
        """
        response_dict = xmltodict.parse(resp)
        resp = response_dict.get("RESPONSE", {})
        self.write({
            "created_in_tally": int(resp.get("CREATED", 0)),
            "altered_in_tally": int(resp.get("ALTERED", 0)),
            "deleted_in_tally": int(resp.get("DELETED", 0)),
            "last_vch_id_tally": int(resp.get("LASTVCHID", 0)),
            "last_mid_tally": int(resp.get("LASTMID", 0)),
            "combined_in_tally": int(resp.get("COMBINED", 0)),
            "ignored_in_tally": int(resp.get("IGNORED", 0)),
            "errors_in_tally": int(resp.get("ERRORS", 0)),
            "cancelled_in_tally": int(resp.get("CANCELLED", 0)),
            "exceptions_in_tally": int(resp.get("EXCEPTIONS", 0)),
        })