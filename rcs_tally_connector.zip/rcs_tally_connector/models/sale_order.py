import requests
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError
from datetime import datetime, date
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET


class SaleOrder(models.Model):
    _inherit = "sale.order"

    tally_id = fields.Char(string="Tally ID", help="Unique identifier for the sale order in Tally")
    master_id = fields.Char(string="Master ID", help="Unique identifier for the master sale order in Tally")
    voucher_key = fields.Char(string="Voucher Key", help="Unique key for the voucher in Tally")
    voucher_retain_key = fields.Char(string="Voucher Retain Key", help="Unique retain key for the voucher in Tally")
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance", )
    tally_operation = fields.Selection([
        ('fetch', 'Fetch from Tally'),
        ('export', 'Export to Tally'),
        ('none', 'No Action')
    ], default='none')
    tally_response = fields.Text(string="Tally Response")
    voucher_type_id = fields.Many2one('voucher.type', domain="[('tally_instance_id','=',tally_instance_id)]",
                                      string="Voucher Type")
    tally_exported = fields.Boolean()

    @api.model
    def default_get(self, fields_list):
        """Set default voucher type based on current model (sale.order)"""
        res = super(SaleOrder, self).default_get(fields_list)
        voucher = self.env['voucher.type'].search([('model_name', '=', 'sale.order')])
        if voucher:
            res['voucher_type_id'] = voucher.id
        return res

    def prepare_xml_sale(self, inputs):
        """
        Prepare XML data for a specific Sale Order.
        This method constructs the XML structure required by Tally for a single sale order.
        """
        # Convert input dates from YYYY-MM-DD to Tally DATE format: YYYYMMDD
        from_date = inputs.start_date
        to_date = inputs.end_date
        if not from_date or not to_date:
            raise AccessError(_("Start date and end date are required."))
        from_date = inputs.start_date.strftime('%Y%m%d').replace('-', '')
        to_date = inputs.end_date.strftime('%Y%m%d').replace('-', '')
        xml_data = f"""<ENVELOPE>
          <HEADER>
            <VERSION>1</VERSION>
            <TALLYREQUEST>EXPORT</TALLYREQUEST>
            <TYPE>COLLECTION</TYPE>
            <ID>SalesOrderVouchers</ID>
          </HEADER>
          <BODY>
            <DESC>
              <STATICVARIABLES>
                <SVFROMDATE TYPE="DATE">{from_date}</SVFROMDATE>
                <SVTODATE TYPE="DATE">{to_date}</SVTODATE>
                <SVCURRENTCOMPANY>INNOVATIVE ENGINEERING PRODUCTS PVT. LTD.</SVCURRENTCOMPANY>
              </STATICVARIABLES>
              <TDL>
                <TDLMESSAGE>
                  <COLLECTION NAME="SalesOrderVouchers" ISMODIFY="No">
                    <TYPE>Voucher</TYPE>
                    <FETCH>DATE</FETCH>
                    <FETCH>VOUCHERTYPENAME</FETCH>
                    <FETCH>PARTYNAME</FETCH>
                    <FETCH>VOUCHERNUMBER</FETCH>
                    <FETCH>ALLLEDGERENTRIES.LIST</FETCH>
                    <FETCH>ALLINVENTORYENTRIES.LIST</FETCH>
                    <FILTERS>IsSalesOrder</FILTERS>
                  </COLLECTION>
                  <SYSTEM TYPE="Formulae" NAME="IsSalesOrder">
                    $VoucherTypeName = "Sales Order"
                  </SYSTEM>
                </TDLMESSAGE>
              </TDL>
            </DESC>
          </BODY>
        </ENVELOPE>"""

        return xml_data

    def _prepare_confirmation_values(self):
        """ Prepare the sales order confirmation values.

        Note: self can contain multiple records.

        :return: Sales Order confirmation values
        :rtype: dict
        """
        return {
            'state': 'sale',
        }

    def import_tally_sales_orders(self, xml_response, tally_instance_id):
        """
        Import sales orders from Tally XML response.
        This method processes the XML response from Tally and creates Sale Orders in Odoo.
        """
        # Placeholder for processing logic
        # This would typically parse the XML response and create Sale Orders
        # based on the data received from Tally.

        # Parse using BeautifulSoup
        soup = BeautifulSoup(xml_response, "xml")
        collection = soup.find("COLLECTION")
        vouchers = collection.find_all("VOUCHER")
        for voucher in vouchers:
            data = {
                # "voucher_key": voucher.get("VCHKEY"),
                # "voucher_type": voucher.get("VCHTYPE"),
                # "objview": voucher.get("OBJVIEW"),
                "name": voucher.VOUCHERNUMBER.text if voucher.VOUCHERNUMBER else None,
                "master_id": voucher.MASTERID.text if voucher.MASTERID else None,
                "voucher_retain_key": voucher.VOUCHERRETAINKEY.text if voucher.VOUCHERRETAINKEY else None,
            }
            partner = self.env['res.partner'].search_partner(voucher)
            if partner:
                data.update({
                    "partner_id": partner.id,
                })
            order_lines = self.env['sale.order.line']._prepare_order_lines_from_voucher(voucher)
            print(data)
            # Create Sale Order
            raw_date = voucher.DATE.text if voucher.find("DATE") else None
            try:
                parsed_date = datetime.strptime(raw_date, "%Y%m%d") if raw_date else None
            except ValueError:
                parsed_date = None

            if order_lines:
                order = self.env['sale.order'].create({
                    'partner_id': partner.id,
                    'date_order': parsed_date,
                    'origin': data["name"],
                    'validity_date': parsed_date,
                    'order_line': order_lines,
                    'create_date': parsed_date,
                    "voucher_key": voucher.get("VCHKEY"),
                    "tally_id": voucher.get("REMOTEID"),
                    "master_id": voucher.MASTERID.text if voucher.MASTERID else None,
                    "voucher_retain_key": voucher.VOUCHERRETAINKEY.text if voucher.VOUCHERRETAINKEY else None,
                    "tally_instance_id": tally_instance_id.id,
                    "client_order_ref": voucher.REFERENCE.text if voucher.REFERENCE else '',
                    'tally_operation': 'import',
                })
                order.client_order_ref = voucher.REFERENCE.text if voucher.REFERENCE else ''
                if parsed_date:
                    query = """
                          UPDATE sale_order
                          SET create_date = %s
                          WHERE id = %s
                      """
                    self.env.cr.execute(query, (parsed_date, order.id))
                self._extract_and_post_tracking_details(voucher, order)
                if tally_instance_id.auto_create_delivery:
                    order.action_confirm()
                    order._create_delivery_from_so()
                if tally_instance_id.auto_create_invoice:
                    order._create_invoice_from_so()

    def _extract_and_post_tracking_details(self, voucher, sale_order):
        tracking_node = voucher.find("AA_VOU_TRACK_HISTORY.LIST")
        if tracking_node is None:
            return

        def _get_nested_text(parent, list_tag, value_tag):
            list_node = parent.find(list_tag)
            if list_node is not None:
                value_node = list_node.find(value_tag)
                return value_node.text.strip() if value_node is not None else ''
            return ''

        # Extract values
        created_date = _get_nested_text(tracking_node, "AA_VOU_CREALT_ON_DATE.LIST", "AA_VOU_CREALT_ON_DATE")
        created_by = _get_nested_text(tracking_node, "AA_VOU_CREALT_BY.LIST", "AA_VOU_CREALT_BY")
        detail = _get_nested_text(tracking_node, "AA_VOU_CREALT_AS_DETAIL.LIST", "AA_VOU_CREALT_AS_DETAIL")
        created_time = _get_nested_text(tracking_node, "AA_VOU_CREALT_ON_TIME.LIST", "AA_VOU_CREALT_ON_TIME")

        # Extract salesperson from UDF field
        salesperson_node = voucher.CRESSALESMANNAME
        if salesperson_node is not None:
            salesperson_name_node = voucher.CRESSALESMANNAME
            salesperson_name = salesperson_name_node.text.strip() if salesperson_name_node is not None else ''
        else:
            salesperson_name = ''

        # Format date and time
        try:
            formatted_date = datetime.strptime(created_date, '%Y%m%d').strftime('%d-%m-%Y')
        except Exception:
            formatted_date = created_date

        try:
            formatted_time = f"{created_time[:2]}:{created_time[2:4]}" if len(created_time) >= 4 else created_time
        except Exception:
            formatted_time = created_time

        # Compose message
        message = f"""
            Voucher Tracking Info
            Created By: {created_by or 'Unknown'}
            Created On: {formatted_date} {formatted_time}
            Details:{detail}
        """

        # Post to chatter (if sale_order is an Odoo recordset)
        if sale_order:
            sale_order.message_post(
                body=message,
                subtype_xmlid="mail.mt_note"
            )
            # Optionally set the salesperson in the order
            if salesperson_name:
                # Try to match with an existing Odoo user
                user = self.env['res.users'].search([('name', 'ilike', salesperson_name)], limit=1)
                if user:
                    sale_order.user_id = user.id
                else:
                    # Optional: set on a custom char field like `x_salesperson_name`
                    pass

    def _create_delivery_from_so(self):
        """Create & Validate Delivery for the Sale Order"""
        for order in self:
            so_create_date = order.date_order

            pickings = order.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))
            for picking in pickings:
                if picking.state == 'draft':
                    picking.action_confirm()
                if picking.state != 'done':
                    picking.action_assign()
                    for move in picking.move_ids_without_package:
                        move.quantity = move.product_uom_qty

                    # validate picking
                    picking.button_validate()

                    # overwrite date_done & scheduled_date after validation
                    if so_create_date:
                        # update done date with ORM
                        picking.write({'date_done': so_create_date})

                        # force scheduled_date + create_date with SQL (because ORM blocks it)
                        self.env.cr.execute(
                            """
                            UPDATE stock_picking
                            SET scheduled_date = %s,
                                create_date = %s
                            WHERE id = %s
                            """,
                            (so_create_date, so_create_date, picking.id),
                        )

    def _create_invoice_from_so(self):
        """Create & Post Invoice for the Sale Order"""
        for order in self:
            so_create_date = order.date_order

            invoices = order._create_invoices()

            for inv in invoices:
                if so_create_date:
                    # set dates before posting
                    inv.write({
                        'invoice_date': so_create_date,
                        'date': so_create_date,
                        'invoice_date_due': so_create_date,
                        'delivery_date': so_create_date,  # if custom field exists
                    })

                # now post the invoice
                inv.action_post()

                if so_create_date:
                    # force create_date with SQL (cannot be set via ORM)
                    self.env.cr.execute(
                        """
                        UPDATE account_move
                        SET create_date = %s
                        WHERE id = %s
                        """,
                        (so_create_date, inv.id),
                    )

    def action_export_tally(self):
        """
        Send Sale Order to Tally on button click
        """
        for order in self:
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {order.name}",
                'message': 'Sale order Export to Tally initiated.',
                'company_id': order.tally_instance_id.company_id.id,
                'res_model': 'sale.order',
                'res_id': order.id,
            })
            self.ensure_one()
            if not order.tally_instance_id or not order.tally_instance_id.url:
                raise UserError("No Tally instance URL configured.")

            payload = order.generate_tally_xml()

            try:
                result = self.tally_instance_id.send_and_process_tally(
                    url=order.tally_instance_id.url,
                    payload=payload,
                    process_log=process_log,
                    success_msg="Successfully Exported Sale Voucher",
                    error_msg="Failed to Export Sale Voucher"
                )
                if result.get('success'):
                    order.tally_response = result.get('raw_response')
                    order.tally_exported = True
                    order.tally_operation = 'export'
                else:
                    order.tally_response = result.get('raw_response')
            except Exception as e:
                process_log.create_log_line(
                    state="error",
                    message=f"Failed to Export sale voucher",
                    response=str(e ),
                    res_model="sale.order",
                )
                order.tally_response = f"Error: {str(e)}"

    def generate_tally_xml(self):
        """
        Generate Tally XML dynamically from Sale Order using ElementTree
        """
        self.ensure_one()
        order = self

        order_date = fields.Datetime.context_timestamp(self, order.date_order).strftime("%Y%m%d")
        partner_name = order.partner_id.name or "Unknown Customer"
        voucher_name = (order.voucher_type_id.name or "Sales Order").strip()
        reference = order.name or "Order"
        godown = order.warehouse_id.name or "Main Location"

        # Compute due date
        due_date = order.commitment_date or order.validity_date or order.date_order
        jd_str = due_date.strftime("%d-%b-%y")
        jd_days = (due_date - date(1900, 1, 1)).days + 2  # tally JD calc

        # Root
        envelope = ET.Element("ENVELOPE")
        header = ET.SubElement(envelope, "HEADER")
        ET.SubElement(header, "TALLYREQUEST").text = "Import Data"

        body = ET.SubElement(envelope, "BODY")
        importdata = ET.SubElement(body, "IMPORTDATA")

        requestdesc = ET.SubElement(importdata, "REQUESTDESC")
        ET.SubElement(requestdesc, "REPORTNAME").text = "Vouchers"

        requestdata = ET.SubElement(importdata, "REQUESTDATA")
        tallymsg = ET.SubElement(requestdata, "TALLYMESSAGE", {"xmlns:UDF": "TallyUDF"})
        voucher = ET.SubElement(tallymsg, "VOUCHER", {"VCHTYPE": voucher_name, "ACTION": "Create"})

        ET.SubElement(voucher, "DATE").text = order_date
        ET.SubElement(voucher, "VOUCHERTYPENAME").text = voucher_name
        ET.SubElement(voucher, "PARTYNAME").text = partner_name
        ET.SubElement(voucher, "EFFECTIVEDATE").text = order_date
        ET.SubElement(voucher, "REFERENCE").text = reference
        ET.SubElement(voucher, "NUMBERINGSTYLE").text = "Auto Retain"
        ET.SubElement(voucher, "PERSISTEDVIEW").text = "Invoice Voucher View"
        ET.SubElement(voucher, "ISDEEMEDPOSITIVE", {"TYPE": "Logical"}).text = "Yes"
        ET.SubElement(voucher, "VOUCHERNUMBERSERIES", {"TYPE": "String"}).text = "Default"

        # Order lines
        for line in order.order_line:
            qty = f"{line.product_uom_qty:.2f} {line.product_uom.name}"
            rate = f"{line.price_unit:.2f}/{line.product_uom.name}"
            amount = f"{line.price_subtotal:.2f}"

            # Tax handling
            tax_name, cgst, sgst, igst = "SALES GST 18%", 9, 9, 18
            if line.tax_id:
                tax = line.tax_id[0]
                tax_name = tax.name
                cgst = sgst = igst = 0
                for t in line.tax_id:
                    if "CGST" in t.name.upper():
                        cgst = t.amount
                    elif "SGST" in t.name.upper() or "UTGST" in t.name.upper():
                        sgst = t.amount
                    elif "IGST" in t.name.upper():
                        igst = t.amount

            entry = ET.SubElement(voucher, "ALLINVENTORYENTRIES.LIST")

            desc_list = ET.SubElement(entry, "BASICUSERDESCRIPTION.LIST", {"TYPE": "String"})
            ET.SubElement(desc_list, "BASICUSERDESCRIPTION").text = line.name or ""

            ET.SubElement(entry, "ISDEEMEDPOSITIVE", {"TYPE": "Logical"}).text = "No"
            ET.SubElement(entry, "STOCKITEMNAME").text = line.product_id.display_name
            ET.SubElement(entry, "GSTOVRDNTAXABILITY", {"TYPE": "String"}).text = "Taxable"
            ET.SubElement(entry, "GSTOVRDNINELIGIBLEITC", {"TYPE": "String"}).text = "¤ Applicable"
            ET.SubElement(entry, "GSTOVRDNISREVCHARGEAPPL", {"TYPE": "String"}).text = "¤ Not Applicable"
            ET.SubElement(entry, "GSTSOURCETYPE", {"TYPE": "String"}).text = "Ledger"
            ET.SubElement(entry, "GSTRATEINFERAPPLICABILITY", {"TYPE": "String"}).text = "As per Masters/Company"
            ET.SubElement(entry, "GSTOVRDNTYPEOFSUPPLY", {"TYPE": "String"}).text = "Goods"
            ET.SubElement(entry, "RATE").text = rate
            ET.SubElement(entry, "ACTUALQTY").text = qty
            ET.SubElement(entry, "BILLEDQTY").text = qty
            ET.SubElement(entry, "GSTLEDGERSOURCE", {"TYPE": "String"}).text = tax_name
            ET.SubElement(entry, "AMOUNT").text = amount

            batch = ET.SubElement(entry, "BATCHALLOCATIONS.LIST")
            ET.SubElement(batch, "GODOWNNAME").text = godown
            ET.SubElement(batch, "BATCHNAME", {"TYPE": "String"}).text = "Any"
            ET.SubElement(batch, "ORDERNO").text = reference
            ET.SubElement(batch, "AMOUNT").text = amount
            ET.SubElement(batch, "ACTUALQTY").text = qty
            ET.SubElement(batch, "BILLEDQTY").text = qty
            ET.SubElement(batch, "ORDERDUEDATE", {"TYPE": "Due Date", "JD": str(jd_days), "P": jd_str}).text = jd_str

            alloc = ET.SubElement(entry, "ACCOUNTINGALLOCATIONS.LIST")
            oldaudit = ET.SubElement(alloc, "OLDAUDITENTRYIDS.LIST", {"TYPE": "Number"})
            ET.SubElement(oldaudit, "OLDAUDITENTRYIDS").text = "-1"
            ET.SubElement(alloc, "LEDGERNAME").text = tax_name
            ET.SubElement(alloc, "AMOUNT").text = amount

            # Add tax rate details
            if cgst:
                ratedetails = ET.SubElement(entry, "RATEDETAILS.LIST")
                ET.SubElement(ratedetails, "GSTRATEDUTYHEAD", {"TYPE": "String"}).text = "CGST"
                ET.SubElement(ratedetails, "GSTRATEVALUATIONTYPE", {"TYPE": "String"}).text = "Based on Value"
                ET.SubElement(ratedetails, "GSTRATE", {"TYPE": "Number"}).text = str(cgst)

            if sgst:
                ratedetails = ET.SubElement(entry, "RATEDETAILS.LIST")
                ET.SubElement(ratedetails, "GSTRATEDUTYHEAD", {"TYPE": "String"}).text = "SGST/UTGST"
                ET.SubElement(ratedetails, "GSTRATEVALUATIONTYPE", {"TYPE": "String"}).text = "Based on Value"
                ET.SubElement(ratedetails, "GSTRATE", {"TYPE": "Number"}).text = str(sgst)

            if igst:
                ratedetails = ET.SubElement(entry, "RATEDETAILS.LIST")
                ET.SubElement(ratedetails, "GSTRATEDUTYHEAD", {"TYPE": "String"}).text = "IGST"
                ET.SubElement(ratedetails, "GSTRATEVALUATIONTYPE", {"TYPE": "String"}).text = "Based on Value"
                ET.SubElement(ratedetails, "GSTRATE", {"TYPE": "Number"}).text = str(igst)

        # Party Ledger
        ledger = ET.SubElement(voucher, "LEDGERENTRIES.LIST")
        ET.SubElement(ledger, "LEDGERNAME").text = partner_name
        ET.SubElement(ledger, "ISDEEMEDPOSITIVE").text = "Yes"
        ET.SubElement(ledger, "ISPARTYLEDGER", {"TYPE": "Logical"}).text = "Yes"
        ET.SubElement(ledger, "AMOUNT").text = f"-{order.amount_total:.2f}"
        ET.SubElement(ledger, "BILLTYPE", {"TYPE": "String"}).text = "On Account"

        # Sales Ledger
        sales = ET.SubElement(voucher, "ALLLEDGERENTRIES.LIST")
        ET.SubElement(sales, "LEDGERNAME").text = "SALES GST 18%"
        ET.SubElement(sales, "ISDEEMEDPOSITIVE").text = "No"
        ET.SubElement(sales, "AMOUNT").text = f"-{order.amount_total:.2f}"

        # Convert to string
        xml_str = ET.tostring(envelope, encoding="utf-8", method="xml").decode("utf-8")
        return xml_str
