import re
from odoo import api, fields, models, _
import xml.etree.ElementTree as ET


class AccountAccount(models.Model):
    _inherit = "account.account"

    fetch_from_tally = fields.Boolean()
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance")


    def prepare_xml_chart_of_accounts(self):
        """
        Prepare XML data for Tally to import Chart of Accounts.
        This method constructs the XML structure required by Tally.
        """
        xml_data = """<ENVELOPE>
    <HEADER>
        <TALLYREQUEST>Export data</TALLYREQUEST>
    </HEADER>
    <BODY>
        <EXPORTDATA>
            <REQUESTDESC>
                <REPORTNAME>List of Accounts</REPORTNAME>
                <STATICVARIABLES>
                    <SVFROMDATE>20250301</SVFROMDATE>
                    <SVTODATE>20250331</SVTODATE>
                    <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
                </STATICVARIABLES>
            </REQUESTDESC>
        </EXPORTDATA>
    </BODY>
</ENVELOPE>"""
        return xml_data

    def import_tally_groups(self, xml_content, instance):
        root = ET.fromstring(xml_content)
        tally_messages = root.findall(".//TALLYMESSAGE")

        for msg in tally_messages:
            group = msg.find('GROUP')
            if group is not None:
                group_name = group.get('NAME')
                parent_name = group.findtext('PARENT') or False
                is_deleted = group.findtext('ISDELETED') == "Yes"
                is_subledger = group.findtext('ISSUBLEDGER') == "Yes"
                affects_gp = group.findtext('AFFECTSGROSSPROFIT') == "Yes"

                if is_deleted:
                    continue

                # Find parent account if already created
                parent = self.env['account.account'].search([('name', '=', parent_name)],
                                                            limit=1) if parent_name else None

                # Determine account_type based on Tally logic
                account_type = self._get_account_type_from_group(group_name, is_subledger, affects_gp)

                # Check if already exists
                existing = self.env['account.account'].search([('name', '=', group_name)], limit=1)
                if existing:
                    continue

                # Create account
                self.env['account.account'].create({
                    'name': group_name,
                    'code': self._generate_code(group_name),
                    'account_type': account_type,
                    'deprecated': False,
                    'tally_instance_id': instance.id,
                    'fetch_from_tally': True,
                })

    def _generate_code(self, name):
        # Keep only alphanumeric characters and dots
        clean_name = re.sub(r'[^A-Za-z0-9.]', '', name[:64])
        return clean_name.upper()

    def _get_account_type_from_group(self, group_name, is_subledger, affects_gp):
        """
        Simplified logic to choose an account_type for Odoo 18
        """
        name = group_name.lower()
        if 'sales' in name:
            return 'income'
        elif 'purchase' in name or 'expense' in name:
            return 'expense'
        elif 'bank' in name or 'cash' in name:
            return 'asset_cash'
        elif 'creditor' in name or 'payable' in name:
            return 'liability_payable'
        elif 'debtor' in name or 'receivable' in name:
            return 'asset_receivable'
        elif is_subledger:
            return 'asset_current'
        elif affects_gp:
            return 'income'
        return 'equity'
