import logging
from odoo import api, fields, models, _
from datetime import datetime
from bs4 import BeautifulSoup
_logger = logging.getLogger(__name__)

class AccountMove(models.Model):
    _inherit = "account.move"

    tally_guid = fields.Char()
    irn = fields.Char("IRN")
    irn_ack_no = fields.Char("IRN Ack No")
    irn_cancel_reason = fields.Char("IRN Cancel Reason")
    irn_cancel_code = fields.Char("IRN Cancel Code")
    irn_qrcode = fields.Binary("IRN QR Code")
    tally_id = fields.Char(string="Tally ID", help="Unique identifier for the sale order in Tally")
    master_id = fields.Char(string="Master ID", help="Unique identifier for the master sale order in Tally")
    voucher_key = fields.Char(string="Voucher Key", help="Unique key for the voucher in Tally")
    voucher_retain_key = fields.Char(string="Voucher Retain Key", help="Unique retain key for the voucher in Tally")
    tally_instance_id = fields.Many2one('tally.sync', string="Tally Instance")

    def prepare_xml_invoice(self, invoice, vouchar, **kwargs):
        xml_request = f"""
       <ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Export Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <EXPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>Voucher Register</REPORTNAME>
        <STATICVARIABLES>
          <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
          <VOUCHERTYPENAME>{vouchar.name}</VOUCHERTYPENAME>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <COLLECTION ISMODIFY="No">
            <TYPE>Voucher</TYPE>
            <NATIVEMETHOD>VoucherNumber</NATIVEMETHOD>
            <NATIVEMETHOD>Date</NATIVEMETHOD>
            <NATIVEMETHOD>VoucherTypeName</NATIVEMETHOD>
            <NATIVEMETHOD>PartyLedgerName</NATIVEMETHOD>
            <NATIVEMETHOD>Narration</NATIVEMETHOD>
            <NATIVEMETHOD>ALLLEDGERENTRIES.LIST</NATIVEMETHOD>
          </COLLECTION>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </EXPORTDATA>
  </BODY>
</ENVELOPE>"""

        return xml_request

    def import_tally_invoice_voucher(self, cleaned_xml, tally_instance, move_type):
        """Import Tally invoice vouchers with error handling and skipping failed ones"""
        soup = BeautifulSoup(cleaned_xml, "xml")
        all_inv_vochers = soup.find_all('TALLYMESSAGE')

        for voc in all_inv_vochers:
            try:
                guid = voc.GUID.text if voc.GUID else False
                name = voc.VOUCHERNUMBER.text if voc.VOUCHERNUMBER else '/'
                description = voc.NARRATION.text if voc.NARRATION else ''
                party_name = voc.PARTYNAME.text if voc.PARTYNAME else ''
                gstin = voc.PARTYGSTIN.text if voc.PARTYGSTIN else False

                # Partner lookup / creation
                partner = self.env['res.partner'].search([('vat', '=', gstin)], limit=1)
                if not partner and party_name:
                    partner = self.env['res.partner'].search([('name', '=', party_name)], limit=1)
                if not partner:
                    partner = self.env['res.partner'].create({'name': party_name, 'vat': gstin or ''})

                # IRN details
                irn = voc.IRN.text if voc.IRN else False
                irn_ack_no = voc.IRNACKNO.text if voc.IRNACKNO else False
                irn_qrcode = voc.IRNQRCODE.text if voc.IRNQRCODE else False

                # Date parsing
                raw_date = voc.DATE.text if voc.find("DATE") else None
                parsed_date = None
                if raw_date:
                    try:
                        parsed_date = datetime.strptime(raw_date, "%Y%m%d")
                    except Exception as e:
                        _logger.warning("Invalid date format for voucher %s: %s", name, e)

                # Move lines
                move_lines = self.env['account.move.line'].prepare_move_lines_from_voucher(voc, move_type)

                if not move_lines:
                    _logger.warning("No move lines for voucher %s, skipping...", name)
                    continue

                # Try creating invoice
                try:
                    self.env['account.move'].create({
                        'partner_id': partner.id,
                        'invoice_date': parsed_date,
                        'invoice_origin': name,
                        'invoice_line_ids': move_lines,
                        'create_date': parsed_date,
                        "voucher_key": voc.get("VCHKEY"),
                        "tally_id": voc.get("REMOTEID"),
                        "master_id": voc.MASTERID.text if voc.MASTERID else None,
                        "voucher_retain_key": voc.VOUCHERRETAINKEY.text if voc.VOUCHERRETAINKEY else None,
                        "tally_instance_id": self.env.context.get('instance_id'),
                        "ref": voc.REFERENCE.text if voc.REFERENCE else '',
                        'narration': description,
                        "irn": irn,
                        "irn_ack_no": irn_ack_no,
                        "irn_qrcode": irn_qrcode,
                        'tally_guid': guid,
                        "move_type": move_type
                    })
                except Exception as e:
                    _logger.error("Failed to create invoice for voucher %s: %s", name, e)
                    continue

            except Exception as e:
                _logger.error("Unexpected error processing voucher: %s", e)
                continue
