import requests
from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError
from datetime import datetime, date
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance", )
    tally_operation = fields.Selection([
        ('fetch', 'Fetch from Tally'),
        ('export', 'Export to Tally'),
        ('none', 'No Action')
    ], default='none')
    tally_response = fields.Text(string="Tally Response")
    voucher_type_id = fields.Many2one('voucher.type', domain="[('tally_instance_id','=',tally_instance_id)]",
                                      string="Voucher Type")
    tally_exported = fields.Boolean()
    tally_id = fields.Char(string="Tally ID", help="Unique identifier for the purchase order in Tally")
    master_id = fields.Char(string="Master ID", help="Unique identifier for the master purchase order in Tally")
    voucher_key = fields.Char(string="Voucher Key", help="Unique key for the voucher in Tally")
    voucher_retain_key = fields.Char(string="Voucher Retain Key", help="Unique retain key for the voucher in Tally")

    def prepare_xml_purchase(self, inputs):
        """
        Prepare XML data for Tally to import Purchase Orders.
        This method constructs the XML structure required by Tally.
        """
        from_date = inputs.start_date
        to_date = inputs.end_date
        if not from_date or not to_date:
            raise AccessError(_("Start date and end date are required."))
        from_date = inputs.start_date.strftime('%Y%m%d').replace('-', '')
        to_date = inputs.end_date.strftime('%Y%m%d').replace('-', '')
        xml_data = f"""<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>COLLECTION</TYPE>
    <ID>PurchaseOrderVouchers</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVFROMDATE TYPE="DATE">{from_date}</SVFROMDATE>
        <SVTODATE TYPE="DATE">{to_date}</SVTODATE>
        <SVCURRENTCOMPANY>INNOVATIVE ENGINEERING PRODUCTS PVT. LTD.</SVCURRENTCOMPANY>
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="PurchaseOrderVouchers" ISMODIFY="No">
            <TYPE>Voucher</TYPE>
            <FETCH>DATE</FETCH>
            <FETCH>VOUCHERTYPENAME</FETCH>
            <FETCH>PARTYNAME</FETCH>
            <FETCH>VOUCHERNUMBER</FETCH>
            <FETCH>ALLLEDGERENTRIES.LIST</FETCH>
            <FETCH>ALLINVENTORYENTRIES.LIST</FETCH>
            <FILTERS>IsPurchaseOrder</FILTERS>
          </COLLECTION>
          <SYSTEM TYPE="Formulae" NAME="IsPurchaseOrder">
            $VoucherTypeName = "Purchase Order"
          </SYSTEM>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>        
        """
        return xml_data

    # def button_approve(self, force=False):
    #     self = self.filtered(lambda order: order._approval_allowed())
    #     self.write({'state': 'purchase'})
    #     self.filtered(lambda p: p.company_id.po_lock == 'lock').write({'state': 'done'})
    #     return {}

    def import_tally_purchase_orders(self, xml_response, tally_instance):
        """        Import Purchase Orders from Tally XML response."""
        if not xml_response:
            raise AccessError(_("No XML response received from Tally."))
        soup = BeautifulSoup(xml_response, "xml")
        collection = soup.find("COLLECTION")
        vouchers = collection.find_all("VOUCHER")
        for voucher in vouchers:
            data = {
                "voucher_key": voucher.get('VCHKEY') or None,
                "date": voucher.DATE,
                "origin": voucher.REFERENCE.text if voucher.REFERENCE else None,
            }
            partner = self.env['res.partner'].search_partner(voucher)
            if partner:
                data.update({
                    "partner_id": partner.id,
                })
            order_lines = self.env['purchase.order.line']._prepare_order_lines_from_voucher(voucher)
            print(data)
            # Create purchase Order
            raw_date = voucher.DATE.text if voucher.find("DATE") else None
            try:
                parsed_date = datetime.strptime(raw_date, "%Y%m%d") if raw_date else None
            except ValueError:
                parsed_date = None

            if order_lines:
                order = self.env['purchase.order'].create({
                    'partner_id': partner.id,
                    'date_order': parsed_date,
                    'origin': data["origin"],
                    'date_approve': parsed_date,
                    'order_line': order_lines,
                    'create_date': parsed_date,
                    "effective_date": parsed_date,
                    "voucher_key": voucher.get("VCHKEY"),
                    "tally_id": voucher.get("REMOTEID"),
                    "master_id": voucher.MASTERID.text if voucher.MASTERID else None,
                    "voucher_retain_key": voucher.VOUCHERRETAINKEY.text if voucher.VOUCHERRETAINKEY else None,
                    "tally_instance_id": tally_instance.id,
                    "picking_type_id": self._get_picking_type(
                        self.env.context.get('company_id') or self.env.company.id).id
                })
                # if parsed_date:
                #     query = """
                #                     UPDATE purchase_order
                #                     SET create_date = %s
                #                     WHERE id = %s
                #                 """
                #     self.env.cr.execute(query, (parsed_date, order.id))
                self._extract_and_post_tracking_details(voucher, order)
                if tally_instance.auto_create_receipt:
                    order.button_confirm()
                    order._create_receipt_from_po()
                if tally_instance.auto_create_bill:
                    order._create_bill_from_po()
                if parsed_date:
                    order.write({
                        'date_approve': parsed_date,
                    })
                    # optional → create_date & write_date bhi override karva hoy to SQL thi update karo
                    self.env.cr.execute("""
                        UPDATE purchase_order
                        SET create_date = %s, write_date = %s
                        WHERE id = %s
                    """, (parsed_date, parsed_date, order.id))

    def _extract_and_post_tracking_details(self, voucher, sale_order):
        tracking_node = voucher.find("AA_VOU_TRACK_HISTORY.LIST")
        if tracking_node is None:
            return

        def _get_nested_text(parent, list_tag, value_tag):
            list_node = parent.find(list_tag)
            if list_node is not None:
                value_node = list_node.find(value_tag)
                return value_node.text.strip() if value_node is not None else ''
            return ''

        # Extract values
        created_date = _get_nested_text(tracking_node, "AA_VOU_CREALT_ON_DATE.LIST", "AA_VOU_CREALT_ON_DATE")
        created_by = _get_nested_text(tracking_node, "AA_VOU_CREALT_BY.LIST", "AA_VOU_CREALT_BY")
        detail = _get_nested_text(tracking_node, "AA_VOU_CREALT_AS_DETAIL.LIST", "AA_VOU_CREALT_AS_DETAIL")
        created_time = _get_nested_text(tracking_node, "AA_VOU_CREALT_ON_TIME.LIST", "AA_VOU_CREALT_ON_TIME")
        # Extract salesperson from UDF field
        salesperson_node = voucher.CRESSALESMANNAME
        if salesperson_node is not None:
            salesperson_name_node = voucher.CRESSALESMANNAME
            salesperson_name = salesperson_name_node.text.strip() if salesperson_name_node is not None else ''
        else:
            salesperson_name = ''

        # Format date and time
        try:
            formatted_date = datetime.strptime(created_date, '%Y%m%d').strftime('%d-%m-%Y')
        except Exception:
            formatted_date = created_date

        try:
            formatted_time = f"{created_time[:2]}:{created_time[2:4]}" if len(created_time) >= 4 else created_time
        except Exception:
            formatted_time = created_time

        # Compose message
        message = f"""
            Voucher Tracking Info
            Created By:{created_by or 'Unknown'}
             Created On: {formatted_date} {formatted_time}
            Details:{detail}
        """

        # Post to chatter (if sale_order is an Odoo recordset)
        if sale_order:
            sale_order.message_post(
                body=message,
                subtype_xmlid="mail.mt_note"
            )
            if salesperson_name:
                # Try to match with an existing Odoo user
                user = self.env['res.users'].search([('name', 'ilike', salesperson_name)], limit=1)
                if user:
                    sale_order.user_id = user.id
                else:
                    # Optional: set on a custom char field like `x_salesperson_name`
                    pass

    def _create_receipt_from_po(self):
        """Create & Validate Receipt for the Purchase Order"""
        for order in self:
            po_create_date = order.date_order

            pickings = order.picking_ids.filtered(lambda p: p.state not in ('done', 'cancel'))
            for picking in pickings:
                if picking.state == 'draft':
                    picking.action_confirm()
                if picking.state != 'done':
                    picking.action_assign()
                    for move in picking.move_ids_without_package:
                        move.quantity = move.product_uom_qty

                    # validate picking
                    picking.button_validate()

                    # overwrite dates after validation
                    if po_create_date:
                        # ORM update for done date
                        picking.write({'date_done': po_create_date})

                        # SQL update for scheduled_date + create_date
                        self.env.cr.execute(
                            """
                            UPDATE stock_picking
                            SET scheduled_date = %s,
                                create_date = %s
                            WHERE id = %s
                            """,
                            (po_create_date, po_create_date, picking.id),
                        )

    def _create_bill_from_po(self):
        """Create & Post Vendor Bill for the Purchase Order"""
        for order in self:
            po_create_date = order.date_order

            vals = order._prepare_invoice()  # Prepare draft values
            bill = self.env['account.move'].create(vals)

            invoice_lines = []
            for line in order.order_line:
                line_vals = line._prepare_account_move_line(bill)

                # Fiscal position mapping here
                fiscal_position = bill.fiscal_position_id or order.fiscal_position_id
                if fiscal_position and line_vals.get("tax_ids"):
                    mapped_taxes = fiscal_position.map_tax(line.taxes_id)
                    line_vals["tax_ids"] = [(6, 0, mapped_taxes.ids)]

                invoice_lines.append((0, 0, line_vals))

            if invoice_lines:
                bill.write({'invoice_line_ids': invoice_lines})

            # set dates
            bill.invoice_date = po_create_date
            bill.date = po_create_date
            bill.invoice_date_due = po_create_date

            # update create_date also
            if po_create_date:
                query = """
                    UPDATE account_move
                    SET create_date = %s,
                        invoice_date = %s,
                        date = %s,
                        invoice_date_due = %s
                    WHERE id = %s
                """
                self.env.cr.execute(
                    query,
                    (po_create_date, po_create_date, po_create_date, po_create_date, bill.id),
                )

            bill.action_post()

    def action_export_tally(self):
        """
        Send Sale Order to Tally on button click
        """
        for order in self:
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {order.name}",
                'message': 'Purchase order Export to Tally initiated.',
                'company_id': order.tally_instance_id.company_id.id,
                'res_model': 'purchase.order',
                'res_id': order.id,
            })
            order.ensure_one()
            if not order.tally_instance_id or not order.tally_instance_id.url:
                raise UserError("No Tally instance URL configured.")

            payload = order.generate_tally_xml()

            try:
                result = self.tally_instance_id.send_and_process_tally(
                    url=order.tally_instance_id.url,
                    payload=payload,
                    process_log=process_log,
                    success_msg="Successfully Exported Purchase Voucher",
                    error_msg="Failed to Export Purchase Voucher"
                )
                if result.get('success'):
                    order.tally_response = result.get('raw_response')
                    order.tally_exported = True
                    order.tally_operation = 'export'
                else:
                    order.tally_response = result.get('raw_response')
            except Exception as e:
                process_log.create_log_line(
                    state="error",
                    message=f"Failed to Export Purchase voucher",
                    response=str(e),
                    res_model="purchase.order",
                )
                order.tally_response = f"Error: {str(e)}"

    def generate_tally_xml(self):
        """
        Generate Tally XML dynamically from Sale Order using ElementTree
        """
        self.ensure_one()
        order = self

        order_date = fields.Datetime.context_timestamp(self, order.date_planned).strftime("%Y%m%d")
        partner_name = order.partner_id.name or "Unknown Customer"
        voucher_name = (order.voucher_type_id.name or "Sales Order").strip()
        reference = order.name or "Order"
        godown = order.picking_type_id.warehouse_id.name or "Main Location"

        # Compute due date
        due_date = order.date_planned
        jd_str = due_date.strftime("%d-%b-%y")
        jd_days = (due_date.date() - date(1900, 1, 1)).days + 2  # tally JD calc

        # Root
        envelope = ET.Element("ENVELOPE")
        header = ET.SubElement(envelope, "HEADER")
        ET.SubElement(header, "TALLYREQUEST").text = "Import Data"

        body = ET.SubElement(envelope, "BODY")
        importdata = ET.SubElement(body, "IMPORTDATA")

        requestdesc = ET.SubElement(importdata, "REQUESTDESC")
        ET.SubElement(requestdesc, "REPORTNAME").text = "Vouchers"

        requestdata = ET.SubElement(importdata, "REQUESTDATA")
        tallymsg = ET.SubElement(requestdata, "TALLYMESSAGE", {"xmlns:UDF": "TallyUDF"})
        voucher = ET.SubElement(tallymsg, "VOUCHER", {"VCHTYPE": voucher_name, "ACTION": "Create"})

        ET.SubElement(voucher, "DATE").text = order_date
        ET.SubElement(voucher, "VOUCHERTYPENAME").text = voucher_name
        ET.SubElement(voucher, "PARTYNAME").text = partner_name
        ET.SubElement(voucher, "EFFECTIVEDATE").text = order_date
        ET.SubElement(voucher, "REFERENCE").text = reference
        ET.SubElement(voucher, "NUMBERINGSTYLE").text = "Auto Retain"
        ET.SubElement(voucher, "PERSISTEDVIEW").text = "Invoice Voucher View"
        ET.SubElement(voucher, "ISDEEMEDPOSITIVE", {"TYPE": "Logical"}).text = "Yes"
        ET.SubElement(voucher, "VOUCHERNUMBERSERIES", {"TYPE": "String"}).text = "Default"

        # Order lines
        for line in order.order_line:
            qty = f"{line.product_uom_qty:.2f} {line.product_uom.name}"
            rate = f"{line.price_unit:.2f}/{line.product_uom.name}"
            amount = f"{line.price_subtotal:.2f}"

            # Tax handling
            tax_name, cgst, sgst, igst = "SALES GST 18%", 9, 9, 18
            if line.taxes_id:
                tax = line.taxes_id[0]
                tax_name = tax.name
                cgst = sgst = igst = 0
                for t in line.taxes_id:
                    if "CGST" in t.name.upper():
                        cgst = t.amount
                    elif "SGST" in t.name.upper() or "UTGST" in t.name.upper():
                        sgst = t.amount
                    elif "IGST" in t.name.upper():
                        igst = t.amount

            entry = ET.SubElement(voucher, "ALLINVENTORYENTRIES.LIST")

            desc_list = ET.SubElement(entry, "BASICUSERDESCRIPTION.LIST", {"TYPE": "String"})
            ET.SubElement(desc_list, "BASICUSERDESCRIPTION").text = line.name or ""

            ET.SubElement(entry, "ISDEEMEDPOSITIVE", {"TYPE": "Logical"}).text = "No"
            ET.SubElement(entry, "STOCKITEMNAME").text = line.product_id.display_name
            ET.SubElement(entry, "GSTOVRDNTAXABILITY", {"TYPE": "String"}).text = "Taxable"
            ET.SubElement(entry, "GSTOVRDNINELIGIBLEITC", {"TYPE": "String"}).text = "¤ Applicable"
            ET.SubElement(entry, "GSTOVRDNISREVCHARGEAPPL", {"TYPE": "String"}).text = "¤ Not Applicable"
            ET.SubElement(entry, "GSTSOURCETYPE", {"TYPE": "String"}).text = "Ledger"
            ET.SubElement(entry, "GSTRATEINFERAPPLICABILITY", {"TYPE": "String"}).text = "As per Masters/Company"
            ET.SubElement(entry, "GSTOVRDNTYPEOFSUPPLY", {"TYPE": "String"}).text = "Goods"
            ET.SubElement(entry, "RATE").text = rate
            ET.SubElement(entry, "ACTUALQTY").text = qty
            ET.SubElement(entry, "BILLEDQTY").text = qty
            ET.SubElement(entry, "GSTLEDGERSOURCE", {"TYPE": "String"}).text = tax_name
            ET.SubElement(entry, "AMOUNT").text = amount

            batch = ET.SubElement(entry, "BATCHALLOCATIONS.LIST")
            ET.SubElement(batch, "GODOWNNAME").text = godown
            ET.SubElement(batch, "BATCHNAME", {"TYPE": "String"}).text = "Any"
            ET.SubElement(batch, "ORDERNO").text = reference
            ET.SubElement(batch, "AMOUNT").text = amount
            ET.SubElement(batch, "ACTUALQTY").text = qty
            ET.SubElement(batch, "BILLEDQTY").text = qty
            ET.SubElement(batch, "ORDERDUEDATE", {"TYPE": "Due Date", "JD": str(jd_days), "P": jd_str}).text = jd_str

            alloc = ET.SubElement(entry, "ACCOUNTINGALLOCATIONS.LIST")
            oldaudit = ET.SubElement(alloc, "OLDAUDITENTRYIDS.LIST", {"TYPE": "Number"})
            ET.SubElement(oldaudit, "OLDAUDITENTRYIDS").text = "-1"
            ET.SubElement(alloc, "LEDGERNAME").text = tax_name
            ET.SubElement(alloc, "AMOUNT").text = amount

            # Add tax rate details
            if cgst:
                ratedetails = ET.SubElement(entry, "RATEDETAILS.LIST")
                ET.SubElement(ratedetails, "GSTRATEDUTYHEAD", {"TYPE": "String"}).text = "CGST"
                ET.SubElement(ratedetails, "GSTRATEVALUATIONTYPE", {"TYPE": "String"}).text = "Based on Value"
                ET.SubElement(ratedetails, "GSTRATE", {"TYPE": "Number"}).text = str(cgst)

            if sgst:
                ratedetails = ET.SubElement(entry, "RATEDETAILS.LIST")
                ET.SubElement(ratedetails, "GSTRATEDUTYHEAD", {"TYPE": "String"}).text = "SGST/UTGST"
                ET.SubElement(ratedetails, "GSTRATEVALUATIONTYPE", {"TYPE": "String"}).text = "Based on Value"
                ET.SubElement(ratedetails, "GSTRATE", {"TYPE": "Number"}).text = str(sgst)

            if igst:
                ratedetails = ET.SubElement(entry, "RATEDETAILS.LIST")
                ET.SubElement(ratedetails, "GSTRATEDUTYHEAD", {"TYPE": "String"}).text = "IGST"
                ET.SubElement(ratedetails, "GSTRATEVALUATIONTYPE", {"TYPE": "String"}).text = "Based on Value"
                ET.SubElement(ratedetails, "GSTRATE", {"TYPE": "Number"}).text = str(igst)

        # Party Ledger
        ledger = ET.SubElement(voucher, "LEDGERENTRIES.LIST")
        ET.SubElement(ledger, "LEDGERNAME").text = partner_name
        ET.SubElement(ledger, "ISDEEMEDPOSITIVE").text = "Yes"
        ET.SubElement(ledger, "ISPARTYLEDGER", {"TYPE": "Logical"}).text = "Yes"
        ET.SubElement(ledger, "AMOUNT").text = f"-{order.amount_total:.2f}"
        ET.SubElement(ledger, "BILLTYPE", {"TYPE": "String"}).text = "On Account"

        # Sales Ledger
        sales = ET.SubElement(voucher, "ALLLEDGERENTRIES.LIST")
        ET.SubElement(sales, "LEDGERNAME").text = "SALES GST 18%"
        ET.SubElement(sales, "ISDEEMEDPOSITIVE").text = "No"
        ET.SubElement(sales, "AMOUNT").text = f"-{order.amount_total:.2f}"

        # Convert to string
        xml_str = ET.tostring(envelope, encoding="utf-8", method="xml").decode("utf-8")
        return xml_str
