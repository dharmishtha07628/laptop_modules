import logging
from datetime import datetime
from odoo import api, fields, models, _
from bs4 import BeautifulSoup
from xml.dom import minidom
from xml.etree.ElementTree import Element, SubElement, tostring
from odoo.exceptions import AccessError, UserError

_logger  = logging.getLogger(__name__)


class AccountPayment(models.Model):
    _inherit = "account.payment"

    tally_guid = fields.Char()
    tally_operation = fields.Selection([
        ('fetch', 'Fetch from Tally'),
        ('export', 'Export to Tally'),
        ('none', 'No Action')
    ], default='none')
    tally_voucher_key = fields.Char()
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance", )
    tally_response = fields.Text(string="Tally Response")
    tally_exported = fields.Boolean()
    voucher_type_id = fields.Many2one('voucher.type', domain="[('tally_instance_id','=',tally_instance_id)]",
                                      string="Voucher Type")

    def prepare_xml_receipt(self, receipt, voucher,**kwargs):
        if kwargs.get('customer'):
            v_type_name = 'Receipt'
            v_type = 'ReceiptVouchers'
        else:
            v_type_name = 'Payment'
            v_type = 'ReceiptVouchers'
        xml_request = f"""
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Export Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <EXPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>Voucher Register</REPORTNAME>
        <STATICVARIABLES>
          <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
          <VOUCHERTYPENAME>{voucher.name}</VOUCHERTYPENAME>
          <FROMDATE>20230401</FROMDATE>
          <TODATE>20240401</TODATE>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <COLLECTION ISMODIFY="No">
            <TYPE>Voucher</TYPE>
            <!-- No filter needed here -->
            <NATIVEMETHOD>VoucherNumber</NATIVEMETHOD>
            <NATIVEMETHOD>Date</NATIVEMETHOD>
            <NATIVEMETHOD>VoucherTypeName</NATIVEMETHOD>
            <NATIVEMETHOD>PartyLedgerName</NATIVEMETHOD>
            <NATIVEMETHOD>Narration</NATIVEMETHOD>
            <NATIVEMETHOD>ALLLEDGERENTRIES.LIST</NATIVEMETHOD>
          </COLLECTION>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </EXPORTDATA>
  </BODY>
</ENVELOPE>

"""
        return xml_request

    def import_tally_receipt_vouchers(self, xml_response, instance,**kwargs):
        print(self)
        soup = BeautifulSoup(xml_response, "xml")
        print(soup)
        tally_message = soup.find_all('TALLYMESSAGE')
        for recept in tally_message:
            date = recept.DATE.text if recept.DATE else False
            if date:
                date_str = date
                date_val = datetime.strptime(date_str, "%Y%m%d").date()
            tally_guid = recept.GUID.text if recept.GUID else ''
            memo = recept.NARRATION.text if recept.NARRATION else ''
            if kwargs.get('customer'):
                default_payment_type = 'inbound'
                default_partner_type = 'customer'
            else:
                default_payment_type = 'outbound'
                default_partner_type = 'supplier'
            partner_name = recept.PARTYLEDGERNAME.text if recept.PARTYLEDGERNAME else ''
            partner = self.env['res.partner'].search([('name', '=', partner_name)], limit=1)
            if not partner:
                partner = self.env['res.partner'].create({'name': partner_name})
            ledger_entries = recept.find_all("ALLLEDGERENTRIES.LIST")
            for entry in ledger_entries:
                amount = float(entry.AMOUNT.text) if entry.AMOUNT else 0.0
                journal = self.env['account.journal'].search([('type', '=', 'bank')], limit=1)
                if amount > 0:
                    payment_vals = {
                        'payment_type': default_payment_type,
                        'partner_type': default_partner_type,
                        'partner_id': partner.id,
                        'amount': amount,
                        'payment_method_id': self.env.ref('account.account_payment_method_manual_in').id,
                        'memo': memo,
                        'date': date_val,
                        'tally_guid': tally_guid,
                        'journal_id': journal.id,
                        'tally_operation': 'fetch',
                        'tally_voucher_key': recept.VOUCHERNUMBER.text if recept.VOUCHERNUMBER else '',
                    }
                    existing_payment = self.env['account.payment'].search([('tally_guid', '=', tally_guid)], limit=1)
                    if not existing_payment:
                        self.env['account.payment'].create(payment_vals)

    def action_export_tally(self):
        """
        Send Sale Order to Tally on button click
        """
        for payment in self:
            process_log = self.env['common.process.log'].create({
                'name': f"Tally Sync - {payment.name}",
                'message': 'Payment Export to Tally initiated.',
                'company_id': payment.tally_instance_id.company_id.id,
                'res_model': 'account.payment',
                'res_id': payment.id,
            })
            self.ensure_one()
            if not payment.tally_instance_id or not payment.tally_instance_id.url:
                raise UserError("No Tally instance URL configured.")

            payload = payment.generate_tally_xml_payment()

            try:
                result = self.tally_instance_id.send_and_process_tally(
                    url=payment.tally_instance_id.url,
                    payload=payload,
                    process_log=process_log,
                    success_msg="Successfully Exported Sale Voucher",
                    error_msg="Failed to Export Sale Voucher"
                )
                if result.get('success'):
                    payment.tally_response = result.get('raw_response')
                    payment.tally_exported = True
                    payment.tally_operation = 'export'
                else:
                    payment.tally_response = result.get('raw_response')
            except Exception as e:
                process_log.create_log_line(
                    state="error",
                    message=f"Failed to Export sale voucher",
                    response=str(e),
                    res_model="sale.order",
                )
                payment.tally_response = f"Error: {str(e)}"

    def generate_tally_xml_payment(self):
        """Generate Tally XML for the payment record(s)."""
        payment = self
        if payment.payment_type  == 'inbound':
            voucher_type = 'Receipt'
        else:
            voucher_type = 'Payment'

        envelope = Element("ENVELOPE")

        # HEADER
        header = SubElement(envelope, "HEADER")
        tally_request = SubElement(header, "TALLYREQUEST")
        tally_request.text = "Import Data"

        # BODY
        body = SubElement(envelope, "BODY")
        import_data = SubElement(body, "IMPORTDATA")

        # REQUESTDESC
        request_desc = SubElement(import_data, "REQUESTDESC")
        report_name = SubElement(request_desc, "REPORTNAME")
        report_name.text = "All Masters"

        # REQUESTDATA
        request_data = SubElement(import_data, "REQUESTDATA")
        tally_message = SubElement(request_data, "TALLYMESSAGE", {"xmlns:UDF": "TallyUDF"})
        voucher = SubElement(tally_message, "VOUCHER", {"ACTION": "Create", "VCHTYPE": "Payment"})

        SubElement(voucher, "VOUCHERTYPENAME").text = voucher_type # Payment/Receipt
        SubElement(voucher, "DATE").text = payment.date.strftime("%Y%m%d")
        SubElement(voucher, "VOUCHERNUMBER").text = payment.name or ""
        SubElement(voucher, "PARTYLEDGERNAME").text = payment.partner_id.name
        SubElement(voucher, "NARRATION").text = payment.memo or ""
        SubElement(voucher, "EFFECTIVEDATE").text = payment.date.strftime("%Y%m%d")

        # Ledger entries
        # Assuming single debit and credit (simple case)
        if payment.payment_type == 'outbound':
            # Money going out: credit cash/bank, debit partner
            credit_entry = {"ledger_name": payment.journal_id.name, "amount": payment.amount,
                            "is_deemed_positive": False}
            debit_entry = {"ledger_name": payment.partner_id.name, "amount": -payment.amount,
                           "is_deemed_positive": True}
        else:
            # Money coming in: debit cash/bank, credit partner
            credit_entry = {"ledger_name": payment.journal_id.name, "amount": -payment.amount,
                            "is_deemed_positive": True}
            debit_entry = {"ledger_name": payment.partner_id.name, "amount": payment.amount,
                           "is_deemed_positive": False}

        for entry in [debit_entry, credit_entry]:
            ledger_entry = SubElement(voucher, "ALLLEDGERENTRIES.LIST")
            SubElement(ledger_entry, "LEDGERNAME").text = entry["ledger_name"]
            SubElement(ledger_entry, "REMOVEZEROENTRIES").text = "NO"
            SubElement(ledger_entry, "LEDGERFROMITEM").text = "NO"
            SubElement(ledger_entry, "ISDEEMEDPOSITIVE").text = "YES" if entry["is_deemed_positive"] else "NO"
            SubElement(ledger_entry, "AMOUNT").text = str(entry["amount"])

        # Pretty print XML
        xml_str = tostring(envelope, encoding="utf-8")

        # Return XML strings (list for multiple payments)
        return xml_str
