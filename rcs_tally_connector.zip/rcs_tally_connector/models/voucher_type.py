from odoo import models, fields, api


class VoucharType(models.Model):
    _name = "voucher.type"

    name = fields.Char(string="Voucher Type", required=True, unique=True)
    model_name = fields.Many2one('ir.model', string="Model Name")
    tally_instance_id = fields.Many2one('tally.instance', string="Tally Instance")
    is_customer_payment = fields.Boolean(string="Is Customer Payment")
    is_vendor_payment = fields.Boolean(string="Is Vendor Payment")
    move_type = fields.Selection(
        [('out_invoice', 'Customer Invoice'), ('in_invoice', 'Vendor Bill'), ('out_refund', 'Customer Credit Note'),
         ('in_refund', 'Vendor Credit Note'), ('entry', 'Journal Entry'), ('out_receipt', 'Customer Payment'),
         ('in_receipt', 'Vendor Payment')], string="Move Type")
    picking_type_id = fields.Many2one('stock.picking.type')
